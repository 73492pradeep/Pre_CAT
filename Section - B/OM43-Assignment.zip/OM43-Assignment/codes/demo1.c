/*
Write a program to accept a number and print all factors excluding the 
number (using loops). Implement code in factors() function.
void factors(int n);
Input: 24
Output: all factors: 1, 2, 3, 4, 6, 8, 12
*/

#include<stdio.h>
void factors(int n);
int main()
{
    int num,i=1;
    printf("Enter the number : ");
    scanf("%d",&num);

    factors(num);

    
    return 0;
}
void factors(int num)
{
    int i = 1;
    while(i <= (num / 2))
    {
        if(num % i == 0 )
            printf(" %d ",i);
        i++;
    }
}
/*
num = 24

% Reminder != 0  // not factore
% reminder == 0  // factor

while(i <= 24)
{
    if(num % i == 0 )
        printf(" %d ",i);
    i++;
}

for(i=1 ; i <= num ; i++)
{

}


*/
