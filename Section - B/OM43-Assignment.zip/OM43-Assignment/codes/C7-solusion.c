/*
Write a function to indicate whether given number is prime or not.
int is_prime(int n); // return 1 if prime and 0 if non-prime.

Write another function to print prime numbers in the given range.
//                  10        50
void print_primes(int min, int max);
*/

#include<stdio.h>
//                    14
int check_prime( int num1);
void print_primes(int min, int max);
// int main()
// {
//     int num ,f ;
//     //printf("Enter number : ");
//     //scanf("%d",&num); // 14  
//     // f = check_prime(num);
//     // if(f == 0)
//     // {
//     //     printf("Num is prime \n");
//     // }
//     // else{
//     //     printf("num is Not Prime \n");
//     // }
//     int max,min;
//     printf("Enter min range : ");
//     scanf("%d",&min);  // 5
//     printf("Enter max range : ");
//     scanf("%d",&max); //50
//     //            5  50
//     print_primes(min,max);
// }
// //                    5         50
// void print_primes(int min, int max)
// {
//     //     6 <  50
//     while(min < max)
//     {
//         //               6
//         if( (check_prime(min)) )
//         {
//             printf("%d ",min);
//         }
//         min++;
//     }
// }
// //                    6
// int check_prime( int num1)
// {
//     int i;
//     for( i = 2 ; i <= num1 / 2  ; i++)
//     {      //14 % 2 == 0
//         if(num1 % i == 0)
//         {
//             return 0;  // Non prime
//         }
//     }
//     return 1;  // prime
// }


/*
2. Write a function to implement four function calculator. Function 
would take operands and operator as arguments and returns 
result.
int calculate(int num1, int num2, char op);

*/
//                 10       20         +-*/
// int calculate(int num1, int num2, char op)
// {
//     int result;
//     switch (op)
//     {
//         case '+':result = num1 + num2 ;
//                 break;
        
//         default:
//             break;
//     }
//     return result;
// }


// a > b ? True : False
// #include <stdio.h>
// int main(void)
// {
//     int value;
//     //                        1 != 1       T     F
//     value= 5 > 8   ? 100   :  1!= 5 <=5 ? 200 : 300;
//     //                T             F
//     printf("Value of value:%d",value);
//     return 0;
// }

// int main()
// {
//     int a=1,b=-1,c=2,d;
//     char ch;
//     short s1;
//     double d1;
//     //  
//         c = sizeof( ++b);
//     //       1--    0++
//         d = (a-- && a++) || c++;
//         //                             0 0 4 1
//         printf("a=%d b=%d c=%d z=%d\n",a,b,c,d);
// }

// int main(){

//         // int k = 8;
//         // //                    XX
//         // int x = ((0 == 1) && (k++));		 	
//         // printf("%d%d\n", x, k);//0 8
//         // return 0;


//     // float x =1.1234567890;
//     // printf("%f\n",x);

//     // //   2
//     // int k = 5/2;  // 2.5

//     // while( x == 1.1f)
//     // {
//     //     printf("%f\n",x);  // 1.123456  1.1234567890
//     //     x = x - 0.1;
//     // }
//   return 0;
// }

//     int a = 10;
//     short s1 ;
//     char ch;
//     int k = sizeof(s1 + ch);
//     printf("a = %d ",a);
// }