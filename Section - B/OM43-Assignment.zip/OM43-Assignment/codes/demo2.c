/*
Write a program to accept integer values of base and index and calculate 
power of base to index. Write logic in user defined power() function.
Pass base & index to function and return result from function.
Input: base: 2 index: 5
Output: 32
Input: base: 8 index: 3
Output: 512
*/

/*

base : 2  , index : 3  // 2^3 =8 .... 2 * 2 * 2

pow = 1;
//        4 <= 3
for(i=1 ; i <= index ; i++)
{
    pow = pow * base ;
    2       1  *  2     //i = 1
    4       2  *  2     // i =2
    8       4  *  2     // i = 3
                        // i = 4
}  

printf("   pow    "   )


*/