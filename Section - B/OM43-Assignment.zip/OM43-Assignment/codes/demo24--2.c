// /*
// Write a function to calculate GCD of given numbers using 
// recursion.
// //           5         55      => 5
// int gcd(int num1, int num2);

// */
// #include<stdio.h>
// int gcd(int num1, int num2);
// int main()
// {
//     int num1,num2 , res;
//     printf("Enter num 1 : ");
//     scanf("%d",&num1);
//     printf("Enter num 2 : ");
//     scanf("%d",&num2);

// //            10      55
//     res = gcd(num1, num2);
//     printf("GCD : %d \n",res);
//     return 0;
// }

// //          10         55
// //          55         10
// //          10          5
// //           5          0
// int gcd(int num1, int num2)
// {
//     // if(num1 == 0 || num2 == 0)
//     // {
//     //         return 0;
//     // }
//     //       55 != 0
//     //       10 != 0
//     //       5  != 0
//     //       0  != 0
//      if(num2 != 0)
//     {
//         //         55     10 % 55  -> 10
//         //         10      5 
//         //          5    10 % 5 -> 0

//         return gcd(num2 , num1 % num2);
//     }
//     else 
//         return num1; // 5
// }

#include<stdio.h>
int main(void)
{
    extern int value;
    printf("%d ", value );
    {
        int value = 100;
        printf("%d ", value);
    }
    return 0;
}