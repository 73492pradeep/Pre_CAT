#include<stdio.h>
int id,dept_no,code;
int main()
{
    scanf("%d%d%*c%c",&id,&dept_no,&code);
    printf("Employee with employee id%d",id);
    switch (dept_no)
    {
    case 10:printf("is working in maeketing");
        break;
    case 20:printf("is working in management");
    break;
    case 30:printf("is working in sales");
    break;
    case 40:printf("is working in desinging");
    break;
    
    default:
    printf("invalid dept_no");
        break;
    }
    switch (code)
    {
    case'M':printf("department as manager");
        break;
    case 'S':printf("department as Supervisor");
        break;    
    case 's':printf("department as Security Officer");
        break;
     case 'C':printf("department as Clerk");
        break;   
    default:
    printf("invalid code");
        break;
    }

}


