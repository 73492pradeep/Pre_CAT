/*
    Write a function to calculate nth term of the Fibonacci series 
    using recursion. 
    int fibo(int n);
                      6
    0 1 2 3 4 5  -----> i
    0 1 1 2 3 5   8 13 .......
*/

#include<stdio.h>
int fibo(int n);
int main()
{
    int num,i;
    printf("Enter the num : ");
    scanf("%d",&num);// 6
    for(i=0 ; i < num ; i++)
    {
        printf("%d ",fibo(i)); // 0  1 1
        //                0 ->0
        //                1 ->1
        //                2 ->1
        //                3 ->2
        //                4 ->3
        //                5 ->5
    }
    return 0;
}


//            3
int fibo(int n)
{
    if(n == 0)
        return 0;
        //printf("55");

    else if(n==1 || n == 2)  
            return 1;
    

    return fibo(n-1) + fibo(n-2); 
     
    //           1
    //     fibo(4)   +  fibo(3)
    //     fibo(3)       +     2
    //     fibo(2)

    return 0;
}