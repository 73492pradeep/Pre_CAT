/*
Write a function to implement four function calculator. Function 
would take operands and operator as arguments and returns result.
In above program, division may fail if denominator is zero. Use global 
variable as an error flag to avoid this problem
*/

#include<stdio.h>

int flag = 0;   // global vaiable // inital value 0
int calc(int num1 , int num2 , char op);
int main()
{
    int n1,n2,res;  //Local variable  // inital value Grabage
    char op;
    printf("Enter num1 : ");
    scanf("%d",&n1);// 44
    
    printf("Enter the op(+ - * /) : ");
    scanf("%*c%c",&op);

    printf("Enter num2 : ");
    scanf("%d",&n2);

    res =calc(n1,n2,op); 

    if(flag == 0) //
    {
        printf("%d %c %d = %d \n",n1,op,n2,res);
    }
    else{
        printf("Error due num2 = 0 and op /");
    }


    int a=5;
    //         5  +  2 + 6 + 7
      int k = a++ + 2 + a   + ++a;  // k // 20


    return 0;
}

int calc(int num1 , int num2 , char op)
{
    int res ;
    switch (op)
    {
        case '+': res = num1 + num2;
                break;
        case '-': res = num1 - num2;
                break;
        case '*': res = num1 * num2;
                break; 

        case '/': if(num2 == 0)
                    {
                       ++flag ;  // flag = 1
                       return;
                    }
                    else{
                        res = num1 / num2 ;
                    }
                break;                       
        
        default:printf("Invalid Operator : ");
            break;
    }
    return res ;
}