//#include<stdio.h>

// int main()
// {
//     // char ch;
//     // ch = 'A';
//     //scanf("%c",&ch);
//     //ch = getchar();

//     //printf("%c ",ch);
//     // printf("%d ",putchar(ch));
//     //      65      A

//     // char str[50];
//     // gets(str);
//     // scanf("%s",str);
//     // puts(str);
//     // printf("%s ",str);

// }

//           3
//           1
//        -1
// int calc(int x) 
// {
//     // 3 <= 0
//     // 1 <= 0
// 	if(x <= 0)
// 		return 1;

//     //     calc(1)       calc(-1)
//     //     clac(-1)     
// 	return calc(x-2) * calc(x-4) + x;
//     //                       1
// }
// int main() 
// {
// 	printf("%d\n", calc(3));	
// 	return 0;
// }


//What will be the data type returned for the following C function?
//    //#include <stdio.h>
//     int func()
//     {
//         return (double)((char)5.0);
//     }
// int main()
// {
//     printf("%d ", func());
// }

// #include<stdio.h>
// register int i; // register variable not declare in global
// void fun()
// {
//     printf("\n Enter value of i::");
//     scanf("%d",&i);
//     printf("\n i=%d i=%u", i, &i);  // reg variables we cant print
//     return;
// }
// int main(void)
// {
//     fun();
//     return 0;
// }

// #include<stdio.h>
// int function(int, int);
// int main(void)
// {
//     int i=531,a=642,k;
//     //         !++531 ,   !++642
//     //         !532       !643
//     //           0          0
//     k=function(!i++,       !++a);
//     //1
//     printf("i=%d a=%d k=%d\n",i,a,k);
//     //                      532,643,1
//     return 0;
// }
// //             0       0
// int function(int j , int b)
// {
//     int c;
//     // 0++  + 0++;
//     c = j++ +  b++;
//     return !c;  //!0 -> 1
//     //      1
// }

// #include<stdio.h>
// int main( void )
// {
//     void *ptr=NULL;

//     //   &100 -> 101
//     char ch=104;

//     //&200 -> 204
//     int no=105;

// //    &300 301 302 304
//     float f=3.412;

//     int sum=0;

// //  100
//     ptr=&ch; 
//     printf("%c", *(char*)ptr);
//     //      h -> 104

//     //sum = sum + *(char*)ptr
//     //104       0  +  104
//     sum+=*(char*)ptr;

//     //200
//     ptr=&no; 
//     //                 200 201 202 203
//     printf("%c", *(int*)ptr);
//     //      i -> 105

//     //                    200
//     //sum = sum + *(char*)ptr
//     //       104 + 105
//     //      209
//     sum+=*(char*)ptr;

//     //300
//     ptr=&f; 
//     //      -4  ,++(3.412)
//     printf("-%.f", ++*(float*)ptr);
//     //sum = 209 + 4.412
//     //213
//     sum+=*(float*)ptr;
//     //                213
//     printf("\tsum=%d", sum);
//     return 0; //hi-4.412  213
// }
/*
int *p = 100  , char *p = 200, float *p = 300    void *p = 500
//   ++p            ++p              ++p            ++(int*)p  ++(char*)p
//  p=104        p = 201            *p = 304        504           501
*/

//In the following program add a statement in the function fun() such that address of a gets stored in j?
 #include<stdio.h>
// int main()
// {
//     int *j;
//     void fun(int**);
//     fun(&j);
//     return 0;
// }
// void fun(int **k)
// //        **k = ga
// //         *k = j
// {
//     int a=10;

//     *k = &a;
    
// }
/*
Options 
 1 .**k=a;
 2. k=&a;
3. *k=&a
4 &k=*a */

int myFunction(int,int);
int main(void)
{
    int result;
    int i=22,j=33;
//  0          22 , 33
    j =  myFunction(i,j);
    //                   22 0
    printf("i=%d j=%d\n",i,j);
    return 0;
}
//                22    33
int myFunction(int a,int b)
{
    //44 =  22 + 22
    a=a+a;
    // b = 33 + 33
    //66
    b=b+b;
    //     66 - 66
    //      0

    return  b-b , 15 ; //
    //return 0

    return a-a; // XX
}

