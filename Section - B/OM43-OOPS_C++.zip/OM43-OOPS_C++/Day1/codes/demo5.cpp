#include<stdio.h>

//bool :- it can take true or false value.
// It takes one byte in memory.

int main()
{
    bool b=true;   // false
    printf("\n bool b=%d   size of bool b=%d",b,sizeof(b));
    return 0;
}