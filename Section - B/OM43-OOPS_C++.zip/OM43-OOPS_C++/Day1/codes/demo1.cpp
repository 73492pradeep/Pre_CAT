
//cpp extension of file is -> .cpp 
//cpp compiler name is -> g++

#include<stdio.h>
//main entry point function 
int main()
{
    printf("\n Hello OM43 ... :)");
    return 0;
}