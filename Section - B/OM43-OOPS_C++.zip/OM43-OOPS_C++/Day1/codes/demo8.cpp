
#include<stdio.h>
//struct in cpp
struct time
{
    //private: Accessible only within the struct
    private:
        int hr;
        int min;
        int sec;
    //public: Accessible within & outside struct
    public:
        void printTime()
        {
            printf("\n Time=%d:%d:%d",hr,min,sec);
        }
        void acceptTime()
        {
            printf("\n Enter Time");
            scanf("%d%d%d",&hr,&min,&sec);
        }
};//end of struct time 
int main()
{
    int n1;
    struct time t1;
    // t1.hr=6;
    // t1.min=30;
    // t1.sec=48;
    //rintTime();
    t1.acceptTime();
    // t1.hr=19;
    t1.printTime();
    return 0;
}