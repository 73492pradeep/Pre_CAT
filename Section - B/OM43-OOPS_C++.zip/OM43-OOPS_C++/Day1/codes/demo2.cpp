#include<stdio.h>

//void printMessage();  //function prototype 

//Inline functions get replaced by compiler at its call statement. 
//It ensures faster execution of function.

//Function Definition
inline void printMessage()
{
    //function body
    printf("\n good evening ... ");
    printf("\n Hello OM43  .. :)");
}
int main()
{
    printMessage();//Function Call
    printMessage();
    printMessage();
    return 0;
}
