#include<stdio.h>
// function overloading.
void printValue(int a)
{
    printf("\n int a=%d",a);
}
//Return type is not considered for function overloading.
// int printValue(int a)
// {
//     printf("\n int a=%d",a);
//     return 9;
// }
void printValue(char ch)
{
    printf("\n char ch=%c",ch);
}
void printValue(int a,int b)
{
    printf("\n int a=%d int b=%d",a,b);
}
void printValue(int a,char ch)
{
    printf("\n int a=%d  char ch=%c",a,ch);
}
void printValue(char ch,int a)
{
    printf("\n char ch=%c  int a=%d",ch,a);
}
int main()
{
    printValue(10);
    printValue('Z');
    printValue(22,33);
    printValue(44,'A');
    printValue('W',55);
    return 0;
}