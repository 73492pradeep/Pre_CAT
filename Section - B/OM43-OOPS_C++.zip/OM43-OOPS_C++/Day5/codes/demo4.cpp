#include<iostream>
using namespace std;

class engine
{
    int cc;
    int fuel;
    public:
    void acceptEngine()
    {
        cout<<"\n enter cc and fuel";
        cin>>this->cc>>this->fuel;
    }
    void printEngine()
    {
        cout<<"\n Engine info cc="<<cc<<" fuel="<<fuel;
    }
};
class car
{
    int price;
    engine e; //object of engine class is data member of car class
    public:
    void acceptCar()
    {
        cout<<"\n enter car price ";
        cin>>this->price;
        this->e.acceptEngine();
    }
    void printCar()
    {
        cout<<"\n car price="<<this->price;
        this->e.printEngine();
    }
};
int main()
{
    engine e1;
    cout<<"\n size of engine e1="<<sizeof(e1);
    e1.acceptEngine();
    e1.printEngine();

    car c1;
    cout<<"\n size of car c1="<<sizeof(c1);
    c1.acceptCar();
    c1.printCar();

}


