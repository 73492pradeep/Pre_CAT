#include<iostream>
using namespace std;
class complex
{
    int real;
    int imag;
    public:
    complex(int r=1,int i=1)
    {
        this->real=r;
        this->imag=i;
    }
    complex(const complex& refc1)  //Copy Constructor
    {
        this->real=refc1.real;
        //refc1.real=99;
        this->imag=refc1.imag;
    }
    void printComplexNumber()
    {
        cout<<"\n complex number="<<this->real<<"+j"<<this->imag;
    }

    // sum of 2 complex number
    //Operator Overloading Using member function   
    complex operator+(complex& c2)
    {
        complex c3;
        c3.real=this->real+c2.real;
        c3.imag=this->imag+c2.imag;
        return c3;
    }
    complex sum(complex& c2)
    {
        complex c3;
        c3.real=this->real+c2.real;
        c3.imag=this->imag+c2.imag;
        return c3;
    } 
    friend complex operator-(complex& c1,complex& c2); 
};
//Operator Overloading Using non member function
//global function
complex operator-(complex& c1,complex& c2)
{
    complex c4;
    c4.real=c1.real-c2.real;
    c4.imag=c1.imag-c2.imag;
    return c4;
}
int main()
{
    complex c1(5,7);
    c1.printComplexNumber();

    complex c2(3,2);
    c2.printComplexNumber();

    complex c3,c4;

   // c3=c1.sum(c2);   // c1.sum(c2);
    c3=c1+c2;        //c1.operator+(c2);
    c3.printComplexNumber();

    c4=c1-c2;   // operator-(c1,c2);
    c4.printComplexNumber();
    // complex cc(c1);  //complex cc=c1;  //Copy Constructor  called
    // cc.printComplexNumber();
    
    
    return 0;
}