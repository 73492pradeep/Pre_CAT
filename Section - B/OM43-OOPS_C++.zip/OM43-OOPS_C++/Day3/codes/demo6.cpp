#include<iostream>
using namespace std;
int main()
{
    int num1;
    num1=10;
    int num2=20;
    num1=55;

    const int c=30;
    //c++;  -> error
    cout<<"\n const c="<<c;
    
    return 0;
}