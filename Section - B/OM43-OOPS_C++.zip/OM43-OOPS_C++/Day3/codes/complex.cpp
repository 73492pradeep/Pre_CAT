//Modular Approach

#include"complex.h"
#include<iostream>
using namespace std;

complex::complex()
    {
        cout<<"\n------complex()------";
        this->real=1;
        this->imag=1;
    }

void complex::show()
{
    cout<<"\n complex number="<<this->real<<"+j"<<this->imag;
}