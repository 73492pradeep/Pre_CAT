//Modular Approach

#include"complex.h"


int main()
{
    complex c1;
    c1.show();
    return 0;
}


//g++ complex.cpp program.cpp