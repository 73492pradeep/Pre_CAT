#include<stdio.h>

int g=100;
namespace ns1
{
    int connection=3307;
    namespace nns
    {
        int a=200;
    }
}
namespace ns2
{
    int connection=4004;
    int num1=11;
    int num2=22;
    int num3=33;
    int num4=44;
    int num5=55;

}

int main()
{
    printf("\n g=%d", ::g);
    printf("\n ns1 connection=%d",ns1::connection);
    printf("\n ns2 connection=%d",ns2::connection);
    printf("\n a=%d",ns1::nns::a);

    using namespace ns2;
    num1=5;
    printf("\n num1=%d",num1);
    printf("\n num3=%d",num3);
    return 0;
}