#include<stdio.h>
#include<iostream>
using namespace std;
//scanf ===> cin
//printf ===> cout
int main()
{
    printf("\n hello om43.. :)");
    cout<<"\n hello om43.. :)";

    int num1=11;
    printf("\n num1=%d",num1);
    cout<<"\n num1="<<num1;

    int num2=22,num3=33;
    printf("\n num2=%d  num3=%d",num2,num3);
    cout<<"\n num2="<<num2<<"  num3="<<num3;

    int a;
    cout<<"\n enter value for a";
   // scanf("%d",&a);
    cin>>a;
    cout<<"\n a="<<a;

    int x,y;
    cout<<"\n enter value for x,y";
    //scanf("%d%d",&x,&y);
    cin>>x>>y;
    cout<<"\n x="<<x<<"  y="<<y;
    
    return 0;
}