
#include<stdio.h>
//Mutators/setter : modify state of object
//inspector/getter : do not change the state of the object
//facilitator : provide extra facility to work with data members


//class in cpp
class time
{
        int hr;
        int min;
        int sec;
    public:
        time()    //Parameterless constructor
        {
            printf("\n ------time()-------");
            this->hr=0;
            this->min=0;
            this->sec=0;
        }
        time(int h,int m,int s)  //Parameterized constructor
        {
            printf("\n ------time(int h,int m,int s)-------");
            hr=h;
            this->min=m;
            this->sec=s;
        }
        void setHr(int hr)//Mutators/setter
        {
            this->hr=hr;
        }
        void setMin(int min)//Mutators/setter
        {
            this->min=min;    
        }
        void setSec(int sec)//Mutators/setter
        {
            this->sec=sec;
        }
        int getSec()//inspector/getter
        {
            return this->sec;
        }
        //int getMin(){}//inspector/getter
        //int getHr(){}//inspector/getter
        void printTime()//facilitator
        {
            printf("\n Time=%d:%d:%d",this->hr,this->min,this->sec);
        }
        void acceptTime()//facilitator
        {
            printf("\n Enter Time");
            scanf("%d%d%d",&this->hr,&this->min,&this->sec);
        }
        void incrTimeByOneSec()//facilitator
        {
            this->sec++;
            if(this->sec>=60) 
            {
                this->min++;
                this->sec=0;
            }
            if(this->min>=60)
            {
                this->hr++;
                this->min=0;
            }
            if(this->hr>=24)
            {
                this->hr=0;
            }
        }
        ~time() //Destructor : used to release the resources
        {
            printf("\n----------- ~time()---------");
        }

};//end of class time 
int main()
{
    // time t1;   
    // t1.printTime();

    // time t2;
    // t2.printTime();

    // time t3;
    // t3.printTime();

    time t_p(7,30,11);    //=>7:30:11
    //t_p.min=15;         //=>7:15:11
    t_p.setMin(15);     
    t_p.printTime();
    //int sec=t_p.sec;
    int sec=t_p.getSec();
    printf("\n only sec=%d",sec);

    // time t_s(8,10,56);   //=>8:10:56
    // t_s.printTime();

    return 0;
}