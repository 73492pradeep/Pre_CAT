#include<iostream>
using namespace std;

class constDemo
{
    int n;
    const int c;  //const data member
    mutable int m;
    public:
    constDemo():c(1),n(1),m(1) //constructors member initializer list.
    {
        //this->n=1;
        //this->c=1;
        //this->m=1;
    }
    void printData()const
    {
        //n++;  --> error
        //c++;  --> error
        m++;   //mutable member allowed to modify in const function
        cout<<"\n n="<<n;
        cout<<"\n c="<<c;
        cout<<"\n m="<<m;
    }
};
int main()
{
    constDemo d1;
    d1.printData();
    
    return 0;
}