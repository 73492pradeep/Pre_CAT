//Modular Approach

class complex {
		int real, imag;
		public:
            complex();
		    void show();
		};
