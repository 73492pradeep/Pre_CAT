#include<iostream>
using namespace std;
int main()
{
    int n1=10;
    int& ref=n1;
    ref=55;

    cout<<"\n value of n1="<<n1<<" address of n1="<<&n1;
    cout<<"\n value of ref="<<ref<<" adrress of ref="<<&ref;
    
    return 0;
}