#include<stdio.h>

class empty
{

};
int main()
{
    empty e1 ,e2;
    printf("\n size of e1=%d",sizeof(e1));
    return 0;
}