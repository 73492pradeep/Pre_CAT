
#include<stdio.h>
//class in cpp
class time
{
        int hr;
        int min;
        int sec;
    public:
        time()    //Parameterless constructor
        {
            printf("\n ------time()-------");
            this->hr=0;
            this->min=0;
            this->sec=0;
        }
        time(int h,int m,int s)  //Parameterized constructor
        {
            printf("\n ------time(int h,int m,int s)-------");
            this->hr=h;
            this->min=m;
            this->sec=s;
        }
        void initTime()
        {
            this->hr=0;
            this->min=0;
            this->sec=0;
        }
        void printTime()
        {
            printf("\n Time=%d:%d:%d",this->hr,this->min,this->sec);
        }
        void acceptTime()
        {
            printf("\n Enter Time");
            scanf("%d%d%d",&this->hr,&this->min,&this->sec);
        }
        ~time() //Destructor : used to release the resources
        {
            printf("\n----------- ~time()---------");
        }

};//end of class time 
int main()
{
    time t1;   
   // t1.initTime();
   // hr min sec => 0:0:0
   // t1.hr=0;
    t1.printTime();

    time t2;
    t2.printTime();

    time t3;
    t3.printTime();

    time t_p(7,30,11);    //=>7:30:11
    t_p.printTime();

    time t_s(8,10,56);   //=>8:10:56
    t_s.printTime();

    return 0;
}