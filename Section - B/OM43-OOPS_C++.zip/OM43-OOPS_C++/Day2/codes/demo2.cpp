
#include<stdio.h>
//class in cpp
class time
{
    //private: Accessible only within the struct
    //private:
        int hr;
        int min;
        int sec;
    //public: Accessible within & outside struct
    public:
        void printTime()
        {
            printf("\n Time=%d:%d:%d",this->hr,this->min,this->sec);
        }

    //If we call member function on object then compiler 
    //implicitly pass address of that object as a 
    //argument to the function implicitly call as this pointer.
        void acceptTime()
        {
            printf("\n Enter Time");
            scanf("%d%d%d",&this->hr,&this->min,&this->sec);
        }
};//end of class time 
int main()
{
    int n1;
    //time-> class   t1->object
    time t1;
    printf("\n size of object t1=%d",sizeof(t1));  //3*4=12
    t1.acceptTime();
    t1.printTime();

    time t2;
    t2.acceptTime();
    t2.printTime();

    time t3;
    t3.acceptTime();
    t3.printTime();


    return 0;
}