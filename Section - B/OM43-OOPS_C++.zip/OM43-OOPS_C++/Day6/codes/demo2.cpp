#include<iostream>
using namespace std;

//base
//parent
class person
{
    string name;
    int age;
    public:
    person()
    {
        this->name="Ravi";
        this->age=32;
    }
    void printPerson()
    {
        cout<<"\n Name="<<this->name<<"  age="<<this->age;
    }
};

//derived
//child
//emp is-a person
class emp : public person
{
    int empid;
    int sal;
    public:
    emp()
    {
        empid=100;
        sal=20000;
    }
    void printEmp()
    {
        this->printPerson();
        cout<<" sal="<<sal;
        cout<<" empid="<<empid;
    }
};

int main()
{
    person p1;
    p1.printPerson();

    emp e1;
    e1.printEmp();
    return 0;
}