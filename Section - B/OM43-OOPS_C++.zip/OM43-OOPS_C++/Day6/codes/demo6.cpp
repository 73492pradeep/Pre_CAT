#include<iostream>
using namespace std;

//base
//parent
class person
{
    protected:
        string name;
        int age;
    public:
    person()
    {
        this->name="Ravi";
        this->age=32;
    }
    void printPerson()
    {
        cout<<"\n Name="<<this->name<<"  age="<<this->age;
    }
};

//derived
//child
//emp is-a person
class emp : public person
{
    int empid;
    int sal;
    public:
    emp()
    {
        empid=100;
        sal=20000;
    }
    void printEmp()
    {
        this->printPerson();
        cout<<" sal="<<sal;
        cout<<" empid="<<empid;
    }
    void updateName(string updatedName)
    {
        this->name=updatedName;//protected data member can be accessible in derived class
    }
};

int main()
{
    //  person p1;
    //  person *pptr=NULL;
    //  pptr=&p1;
    //  pptr->printPerson();

    //  emp e1;
    //  emp *eptr=NULL;
    //  eptr=&e1;
    //  eptr->updateName("Ravee");
    //  eptr->printPerson();
    //  eptr->printEmp();

     emp e1;
     person *pptr=NULL;
     pptr=&e1;  //no error-->base class pointer can hold the address of derived class object
     pptr->printPerson();


 

   

//==================================

    int num=55;
    int *ptr=NULL;
    ptr=&num;
    //---------------------
    char ch='A';
    char* chptr=NULL;
    chptr=&ch;
    //-----------------------
    //chptr=&num;  //-->error 

    return 0;
}