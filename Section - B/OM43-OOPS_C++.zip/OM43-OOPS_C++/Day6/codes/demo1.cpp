#include<iostream>
using namespace std;
// parent class
class base
{
    public:
    int b;
    void funBase()
    {
        cout<<"\n ----base::funBase()---";
    }
};
//child class
class derived:public base
{
    public:
    int d;
    void funDerived()
    {
        cout<<"\n ----derived::funDerived()----";
    }
};
int main()
{
    // base b1;
    // cout<<"\n size of b1="<<sizeof(b1);  ==4
    // b1.b=10;
    // cout<<"\n base::b"<<b1.b;
    // b1.funBase();

    derived d1;
    cout<<"\n size of d1="<<sizeof(d1); //==8
    d1.d=20;
    d1.b=30;
    d1.funDerived();
    d1.funBase();

    return 0;
}