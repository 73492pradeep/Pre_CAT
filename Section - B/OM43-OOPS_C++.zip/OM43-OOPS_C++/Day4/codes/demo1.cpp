#include<iostream>
using namespace std;

//int a1=a;
//  void mySwap(int a1,int b1)
//  {
//      int t=a1;
//      a1=b1;
//      b1=t;
//  }

//int& refa=a
//variable is passed by reference in function

 void mySwap(int& refa,int& refb)
 {
     int t=refa;
     refa=refb;
     refb=t;
 }

int main()
{
    int a=11,b=99;
    cout<<"\n before swap a="<<a<<"  b="<<b;
    mySwap(a,b);
    cout<<"\n after swap a="<<a<<"  b="<<b;
    cout<<"\n";
    return 0;
}