#include<iostream>
using namespace std;
class complex
{
    int real;
    int imag;
    public:
    complex(int r=1,int i=1)
    {
        this->real=r;
        this->imag=i;
    }
    complex(complex& refc1)  //Copy Constructor
    {
        this->real=refc1.real;
        this->imag=refc1.imag;
    }
    void printComplexNumber()
    {
        cout<<"\n complex number="<<this->real<<"+j"<<this->imag;
    }
    // sum of 2 complex number
    complex sum(complex& c2)
    {
        complex c3;
        c3.real=this->real+c2.real;
        c3.imag=this->imag+c2.imag;
        return c3;
    }  
};
int main()
{
    complex c1(5,7);
    c1.printComplexNumber();

    complex c2(3,2);
    c2.printComplexNumber();

    complex c3;

    c3=c1.sum(c2); 
    c3.printComplexNumber();


    // complex cc(c1);  //complex cc=c1;  //Copy Constructor  called
    // cc.printComplexNumber();
    
    
    return 0;
}