#include<iostream>
using namespace std;
class complex
{
    int real;
    int imag;
    public:
    complex(int r=1,int i=1)
    {
        cout<<"\n ------- complex(int ,int)------";
        this->real=r;
        this->imag=i;
    }
    void printComplexNumber()
    {
        cout<<"\n complex number="<<this->real<<"+j"<<this->imag;
    } 
    ~complex()
    {
        cout<<"\n ------- ~complex()------";
    }
};
int main()
{
    complex c1(5,7);
    c1.printComplexNumber();

//Object get created on heap section hence this object is call Heap based  or dynamic object.
    complex* cptr=new complex(5,7);
    cptr->printComplexNumber();
    delete cptr;
    cptr=NULL;

    complex c2(3,2);
    c2.printComplexNumber();
    
    return 0;
}


 // complex* cptr1=(complex*)malloc(8);
    // cptr1->printComplexNumber();
    // free(cptr1);
    // cptr1=NULL;