#include<iostream>
using namespace std;

int main()
{

    int n,d;
    try
    {
        cout<<"\n enter n and d";
        cin>>n>>d;
        if (d==0)
            throw "error";
        int r=n/d;
        cout<<"\n result="<<r;
    }
    catch(int e)
    {
        cout<<"\n  ---int --";
        cout<<"devide by zero error";
    }
    catch(char e)
    {
        cout<<"\n  ---char --";
        cout<<"devide by zero error";
    }
    catch(...)
    {
        cout<<"\n  --- (...) --";
        cout<<"devide by zero error";
    }

    
   

    cout<<"\n";
    return 0;
}