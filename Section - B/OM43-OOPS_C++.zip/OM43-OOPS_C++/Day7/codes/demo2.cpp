#include<iostream>
using namespace std;

class shape ////Abstract class
{
    public:
    virtual void calArea()=0;//Pure virtual function 
    virtual void calPeri()=0; //Pure virtual function 
};
class square:public shape  //Abstract class
{

};
class rect:public shape
{
    int l,b;
    public:
    rect(int l=2,int b=3)
    {
        this->l=l;
        this->b=b;
    }
    //Function overriding.
    void calArea()
    {
        int a=l*b;
        cout<<"\n area of rect="<<a;
    }
    //Function overriding.
    void calPeri()
    {
        int p=2*(l+b);
        cout<<"\n peri of rect="<<p;
    }
};
class circle:public shape
{
    int r;
    public:
    circle(int r=4)
    {
        this->r=r;
    }
    //Function overriding.
    void calArea()
    {
        int a=3.14*r*r;
        cout<<"\n area of circle="<<a;   
    }
    //Function overriding.
    void calPeri()
    {
        int p=2*3.14*r;
        cout<<"\n peri of circle="<<p;
    }
};
int main()
{
    shape *sptr=NULL;
    rect r1(4,6);
    circle c1(6);
    int ch;
    do
    {
       cout<<"\n 1:rect 2:circle 0:exit";
       cin>>ch;
       switch (ch)
       {
       case 1://rect
           sptr=&r1;
           break;
       case 2://circle
           sptr=&c1;
           break;
       }
       if(sptr !=NULL)
       {
           sptr->calArea();
           sptr->calPeri();
       }
       sptr=NULL;
    } while (ch!=0);
    



    //square s1;
    // shape sp;
    // sp.calArea();
    // sp.calPeri();

    // rect r1(4,6);
    // r1.calArea();
    // r1.calPeri();

    // circle c1(6);
    // c1.calArea();
    // c1.calPeri();
}