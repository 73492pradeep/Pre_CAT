#include<iostream>
using namespace std;
//base
//parent
class person
{
    protected:
        string name;
        int age;
    public:
    person()
    {
        this->name="Ravi";
        this->age=32;
    }
     //Virtual function = It is the function which is  called depending on type of object 	rather than type of pointer 
    virtual void accept()  //==>2
    {
        cout<<"\n enter name and age";
        cin>>name>>age;
    }
    void printPerson()
    {
        cout<<"\n Name="<<this->name<<"  age="<<this->age;
    }
};

//derived
//child
//emp is-a person
class emp : public person
{
    int empid;
    int sal;
    public:
    emp()
    {
        empid=100;
        sal=20000;
    }
    void printEmp()
    {
        this->printPerson();
        cout<<" sal="<<sal;
        cout<<" empid="<<empid;
    }
    ////Function overriding.
    void accept()
    {
        person::accept(); //==>2
        cout<<"\n enter sal and empid";
        cin>>sal>>empid;
    }
    void updateName(string updatedName)
    {
        this->name=updatedName;//protected data member can be accessible in derived class
    }
};

int main()
{
    //  person p1;
    //  person *pptr=NULL;
    //  pptr=&p1;
    //  pptr->printPerson();
    //  pptr->accept();
    //  pptr->printPerson();

    //  emp e1;
    //  emp *eptr=NULL;
    //  eptr=&e1;
    //  eptr->printEmp();
    //  eptr->accept();
    //  eptr->printEmp();

     emp e1;
     person *pptr=NULL;
     pptr=&e1;  //no error-->base class pointer can hold the address of derived class object
     pptr->accept();
     //pptr->updateName();
     pptr->printPerson();



 

   

//==================================

    int num=55;
    int *ptr=NULL;
    ptr=&num;
    //---------------------
    char ch='A';
    char* chptr=NULL;
    chptr=&ch;
    //-----------------------
    //chptr=&num;  //-->error 

    return 0;
}