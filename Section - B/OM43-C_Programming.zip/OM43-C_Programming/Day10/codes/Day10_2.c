#include <stdio.h>
int addition(int a, int b); //function decln
int main()
{
    //num1 and num2 are called as local var
    int num1 = 10;
    int num2 = 20;
    int res;
    res = addition(num1, num2); //function call
    printf("sum = %d\n", res);//30 
    res = addition(30, 40); //function call
    printf("sum = %d\n", res);//70
    res = addition(100, 20); //function call
    printf("sum = %d\n", res);//120 
    addition(2, 3); //function call
    //catching the value is optional 
    return 0;
}

int addition(int a, int b)
{
    int c;     // local variable
    c = a + b; //5
    return c;
}

//int addition(int a,int b); 
// int => return type
// addition => name of the function 
// a and b => formal argument 