#include<stdio.h> 
int addition(int a , int b); //function decln 
int main()
{
    //num1 and num2 are called as local var
    int num1 = 10;
    int num2 = 20; 
    int res; 
    res = addition( num1 ,num2 ); //function call 
    //num1 and num2 are called actual argument 
    printf("sum = %d",res); 
    return 0;
}

//main function => calling function 
//addition function => called function 

//function defination 
// a and b are called as formal arguments 
int addition(int a , int b)
{
    // a and b are local to the function addition 
    // a and b are called as local variables 
    int c; // local variable 
    c = a + b; //30 
    return c;  
}

