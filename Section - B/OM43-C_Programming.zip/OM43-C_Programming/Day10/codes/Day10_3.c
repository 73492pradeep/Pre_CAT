#include<stdio.h> 

//function can return only value from the function 

//function declaration 
double addition( double num1 , double num2 );
void multiplication( double a, double b ); 
int division( int num , int den ); 
void subtract( void ); 
int main( void ) // user defined function 
{
    double num1=10.00,num2=20.00,res; //local variables 
    //variable declared inside the function are called as local var 
    
    res = addition(num1,num2); 
    printf("Addition = %.2lf",res); 
    
    multiplication(2.0,4.0); //function call 
    
    int num,den,ans; 
    printf("\n Enter num and den:: ");
    scanf("%d%d",&num,&den); 
    ans = division(num,den); //function call  
    printf("\n ans = %d",ans); 
    
    subtract(   ); //function call 
    
    return 0; 

}

//user defined function 

void subtract( void )
{
    int p,q,r; //local variable 
    printf("\n Enter 2 values..::"); 
    scanf("%d%d",&p,&q);
    r = p - q; 
    printf("\n result = %d",r);  
}

int division( int num , int den )
{
    //int r; 
    //r = num / den; 
    //return r; 
    return num/den;
}

void multiplication( double a, double b )
{
      double res;  
      res = a * b; 
      printf("\n res = %.2lf",res);   
}

double addition( double num1 , double num2 )
{
    //num1 and num2 are local to addition 
    double res; 
    res = num1 + num2; 
    return res;  
}
//API => function 

//fun1(10); // ERROR  
//void fun1( void ); 

//fun2(10); // NO ERROR 
//void fun2(  ); 

/*

    void add1(int x ); 
  //add1 is taking 1 argument of type intger 
  but it is not returning any value to calling function 

   float fun1( void )
   // fun1 is not taking any i/p from calling function 
   but it is returning a value of type float to calling function 

   float sunbeam(int x , float y)
   // sunbeam function is taking i/p from calling funtion of type 
   int and float and returning value of type float   

   void fun12(void); //function not taking i/p and not returning anything    


*/