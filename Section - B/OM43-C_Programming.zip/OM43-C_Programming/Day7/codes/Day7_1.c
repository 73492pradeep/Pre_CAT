#include <stdio.h>
int main( void )
{
    //printf("%d ",10 & 5);
    //printf("%d ",10 | 5);
    //printf("%d ",10 ^ 5); 
    
    //Bitwise not ~

    printf("%d ",~10);//-(n+1)=>-(10+1)=>-11 
    /*
            1.Convert 10 to binary 

            0000 1010 
            Bitwise not 
            (inverting the bits )
            1111 0101 
            ( 2s Compliment )

        1s Compliment 0000 1010

        2s Compliment 
                      0000 1010 
                              1
                     -----------
                      0000 1011  => 11          
            ans => -11 
    */ 
    
    return 0;
}