#include<stdio.h> 

int main( )
{
    int num1 = 20; 
    int num2 = 30; 
    int ans; 
    /*
        if(num1 > num2) 
            exp1
        else 
            exp2 
    */
    ans = num1 > num2 ? num1 : num2; 
    //printf("ans = %d",ans); 
    //       condtn   ? exp1 : exp2  
    num1 > num2 ? printf("num1 is greatest") : printf("num2 is greatest"); 
    
    
    return 0; 
}
/*
        Greatest of 3 numbers 
        num1,num2,num3 ==> condtn opr 

ans = num1 > num2 ? ( num1 > num3 ? num1 : num3 ) : ( num2 > num3 ? num2 : num3 );         
//      condtn    ?         exp1                  :             exp2  


//greatest of a,b,c 

 a>b && a>c ? printf("%d",a) : ( b > c ? printf("%d",b) : printf("%d",c ) ) ;    


 max = a > b && a > c ? a : ( b > c ? b : c); 
 printf("max = %d",max);   

*/