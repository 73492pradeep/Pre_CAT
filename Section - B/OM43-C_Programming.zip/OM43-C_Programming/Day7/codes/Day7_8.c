#include <stdio.h>

int main()
{
    int num;
    printf("Enter the num");
    scanf("%d", &num);//44
    if (num == 1)
        printf("one");
    else if (num == 2)
        printf("two");
    else if (num == 3)
        printf("three");
    else
        printf("Invalid");
    return 0;
}