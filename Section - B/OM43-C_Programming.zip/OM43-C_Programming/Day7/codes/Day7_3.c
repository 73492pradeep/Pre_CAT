#include<stdio.h> 
/*
        Infection count 
        if infection count >=1000 (impose the lockdown)

*/
int main( )
{
    int count; 
    printf("Enter the count"); 
    scanf("%d",&count); //900
    if(count>=1000)//if(900>=1000)=>if(0)
    {
        printf("Impose the lockdown"); 
    }
    else 
    {
        printf("\n No lockdown"); 
    } 
    return 0; 
}
