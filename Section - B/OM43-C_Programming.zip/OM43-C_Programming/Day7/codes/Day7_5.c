#include<stdio.h> 

int main( )
{
    int num1 = 100; 
    int num2 = 1000; 
    int num3 = 3000; 
    if(num1 > num2)//100 > 1000 => F 
    {
        if(num1 > num3)
        {
            printf("num1 is greatest"); 
        }
        else 
        {
            printf("num3 is greatest");
        }
    }
    else 
    {
        if(num2 > num3)//1000 > 3000=>F
        {
            printf("num2 is greatest"); 
        }
        else 
        {
            printf("num3 is greatest"); 
        }
    }
    return 0; 
}
/*
    100 10 20
    //nested if-else 

    if(condtn)
    {
        if(condtn)
        {
             
        }
        else
        {

        }
    } 
    else 
    {
        if()
        {

        }
        else
        {

        }
    }

*/