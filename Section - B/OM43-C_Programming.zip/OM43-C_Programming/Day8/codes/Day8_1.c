#include<stdio.h> 

int main( )
{
    // if(-1) //-1 => True 
    //  printf("Hello"); 
    // else 
    //  printf("world"); 

    // int a = 1; 
    // if(a = 2) //if(2)=>if(T)
    //  printf("Hello"); 
    // else 
    //  printf("world"); 

    // int a = 1; 
    // if(a == 2) //if(0)=>if(F)
    //  printf("Hello"); 
    // else 
    //  printf("world"); 

    // if(printf("hi")) //if(2)=> if(T)
    //    printf("world"); 
    // else 
    //    printf("world1"); 

    // if(!printf("hi")) //if(2)=> if(!T)=>if(F)
    //    printf("world"); 
    // else 
    //    printf("world1"); 

    //if(1,2,3,4) 
    // if(1,2,3,0) 
    //    printf("world"); 
    // else 
    //    printf("world1"); 

    // if(printf("hi"),printf("hello"),printf("ok"))//if(2)
    //         printf("True");
    // else 
    //         printf("False"); 

    if(printf("hi"),printf("hello"),printf("ok"),0)//if(0)=>if(F)
            printf("True");
    else 
            printf("False"); 

    return 0; 
}

// int main( )
// {
//        int a = 11; 

//     if(a==11)
//     {
//       printf("Hello"); 
//       printf("world"); 
//     }
//     else 
//       printf("world1"); 
//     // int a = 11; 

//     // if(a==11)
//     //   printf("Hello"); 


//     //   printf("world"); 
//     // else 
//     //   printf("world1"); 
//     return 0; 
// }

// int main()
// {
//     int a = 9; 
//     int b = 12; 

//     if(a==10)
//     if(b==13);
    
//       printf("Hello");
//     else 
//       printf("world");  
//     return 0;
// }

// int main()
// {
//     int a = 9; 
//     int b = 12; 

//     if(a==10);
    
//     if(b==13)
//       printf("Hello");
//     else 
//       printf("world");  
//     return 0;
// }



// int main()
// {
//     int a = 9; 
//     int b = 12; 

//     if(a==10)
//     if(b==13)
//       printf("Hello");
//     else 
//       printf("World"); 
//     else 
//       printf("Outside if-else"); 
//     /*
//          if(a==10)
//         {
//             if(b==13)
//               printf("Hello");
//            else 
//               printf("World");
//         }
//         else 
//             printf("Outside if-else"); 
//     */
//     return 0;
// }
