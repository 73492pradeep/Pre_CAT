#include<stdio.h> 
int main()
{
    //break
    //int i = 1; 
    //if(i == 1)
    //   break; //NOT OK 
    
    int i = 1; 
    for( i = 1; i<=5 ; i++)
    {
        printf("%d",i);//1 2 3    
        if(i == 3)
          break; 
    }
    printf("\n outside the loop %d",i); 
    return 0;
}
