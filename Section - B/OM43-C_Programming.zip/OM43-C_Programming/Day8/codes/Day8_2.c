#include<stdio.h> 

int main( )
{
    int num = 0; 
    int a = 1;
    int b = 2; 
    //switch( 1 ) 
    //switch( 2 - 1  ) 
    switch( a + b)
    {
     
        //case 12 && 13: //case 1: 
        case 12 && 0: //case 0: 
        //case a + b: // NOT OK   
        printf("A"); 
        break; 

        case 1: 
        printf("One\n"); 
        break; 

        case 2: 
        printf("Two\n"); 
        break; 

        case 3:
        printf("Three\n"); 
        break;  

        default: 
        printf("Invalid");
        break;     

              
    }


// int main( )
// {
//     int num = 100; 

   
//     switch( num  )
//     {
     
//         //case 'A':
//         //case  1:  
//         //case 99: 
//         //case 100:  
//         case 'A' : case 100: 
//         printf("A"); 
//         break; 
   
//         case 2: 
//         printf("Two\n"); 
//         break; 

//         case 3:
//         printf("Three\n"); 
//         break;  

//         default: 
//         printf("Invalid");
//         break;     

              
//     }


// int main( )
// {
//     int num = 22; 

//     //switch( 1 ) 
//     //switch( 2 - 1  ) 
//     switch( 'A' )
//     {
     
//         case 65: 
//         //case 'A'://case 65:  
//         printf("A"); 
//         break; 
//         case 1: 
//         //case 1.5: // NOT OK 
//         //case 2 - 1: //case 1: => OK  
//         //case 2: 
//         //case -1: 
//         printf("One\n"); 
//         break; 

//         case 2: 
//         printf("Two\n"); 
//         break; 

//         case 3:
//         printf("Three\n"); 
//         break;  

//         default: 
//         printf("Invalid");
//         break;     

              
//     }

// int main( )
// {
//     int choice = 22; 

//     switch( choice )//22 
//     {
//         default: 
//         printf("Invalid");
//         break;     

//         case 2: 
//         printf("One\n"); 
//         break; 

//         case 1: 
//         printf("Two\n"); 
//         break; 

//         case 3:
//         printf("Three\n"); 
//         break;  

              
//     }
    // switch( choice )//22 
    // {
    //     case 1: 
    //     printf("One\n"); 
    //     break; 

    //     case 2: 
    //     printf("Two\n"); 
    //     break; 

    //     case 3:
    //     printf("Three\n"); 
    //     break;  

    //     default: 
    //     printf("Invalid");      
    // }  
    return 0; 
}



// int main( )
// {
//     int choice = 1; 

//     switch( choice )//1 
//     {
//         case 1: 
//         printf("One\n"); 
//         case 2: 
//         printf("Two\n"); 
//         case 3:
//         printf("Three\n");       
//     }  
//     return 0; 
// }

