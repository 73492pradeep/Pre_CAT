#include<stdio.h> 
int main()
{
    //for , while ( entry controlled loop )
    //do-while ( exit controlled loop )

    do
    {
        printf("Hello world"); 
    } while (0);
    
    return 0;
}
