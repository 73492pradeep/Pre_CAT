#include<stdio.h> 

int main( )
{
    // printf("Hello world"); 
    // printf("Hello world"); 
    // printf("Hello world"); 
    // printf("Hello world"); 
    // printf("Hello world"); 
    
    //while , for , do-while 

    //while  
    // int i = 1;
    // while( i <= 5) // infinite loop  
    // //while( 1 <= 5)=> while(1)
    // //while( 1 <= 5)=> while(1)
    // //while( 1 <= 5)=> while(1)
    // //while( 1 <= 5)=> while(1)
    // //while( 1 <= 5)=> while(1)
    // //while( 1 <= 5)=> while(1)
    // {
    //     printf("Hello world\n"); 
    // }

    // int i = 1;
    // while( i <= 5) // infinite loop  
    // //while( 1 <= 5)=> while(1)
    // //while( 2 <= 5)=> while(1)
    // //while( 3 <= 5)=> while(1)
    // //while( 4 <= 5)=> while(1)
    // //while( 5 <= 5)=> while(1)
    // //while( 6 <= 5)=> while(0)
    // {
    //     printf("Hello world\n"); 
    //     i++; 
    //     //++i; 
    //     //i = i + 1; 
    //     //i+=1;  
    // } 

    //  int i = 1; 
    //  while( i<=5)
    //  {
    //      printf("%d",i); //1 2 3 4 5    
    //      i++;  
    //  }
    //  printf("\n outside the loop %d",i); //6 

    // int i = 1; 
    // while( i<=5)
    // {
    //     printf("%d",i++); //1 2 3 4 5     
        
    // }
    //  printf("\n outside the loop %d",i); //6 

    // int i = 1; 
    // while( i<=5)
    // {
    //     printf("%d",++i);//2 3 4 5 6     
        
    // }
    //  printf("\n outside the loop %d",i); //6 


    // int i = 1; 
    // while( i<=5); // infinite loop 
    
    
    
    // {
    //     printf("%d",i++); 
        
    // }
    //  printf("\n outside the loop %d",i); 


    //int i = 1; 
    //while( i++<=5); 
    //     1++<=5 
    //     2++<=5 
    //     3++<=5
    //     4++<=5
    //     5++<=5 
    //     6++<=5 
    
    
    
    // {
    //     printf("%d",i); // 7 
        
    // }
    //  printf("\n outside the loop %d",i); //7 

    // char ch = 0; 
    // while(ch++) //while(0++)=>while(f)
    // {
    //     printf("%d",ch); 
    // }
    // printf("\n outside the loop %d",ch); 

    // char ch = 0; // 127 ... 0 .... -128 
    // while(++ch) //while(1)
    // {
    //     printf("%d %c\n",ch,ch); 
    // }
    
    // int i = 1; 
    // int j = 1; 
    // while(i<=5 , j<=10)
    // {
    //     printf("\n %d %d",i,j); 
    //     i++,j++; 
    // }
    int i = 1; 
    int j = 1; 
    while(i<=10 , j<=5 )
    {
        printf("\n %d %d",i,j); 
        i++,j++; 
    }

    return 0; 
}