#include<stdio.h> 

int main( )
{
    //continue
    //continue takes the control to the nearest loop  
    
    //return => function topic 

    // int i = 1; 
    // if(i==1) 
    //   continue; // NOT OK   
    
    int i = 2; 
    for( i = 2 ; i<=10 ; i++)
    {
        if(i % 2 == 0 )
            continue; 
        printf("%d",i); //3 5 7 9    
    }
    
    
    
    return 0; 
}