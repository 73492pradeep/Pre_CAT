#include<stdio.h> 


int main( )
{
    char ch; 
    int num; 
    // printf("Enter the char");
    // scanf("%c%d",&ch,&num);

    // printf("%c %d",ch,num);   
    printf("Enter the int and char");
    //scanf("%d%c",&num,&ch);
    scanf("%d%*c%c",&num,&ch);

    printf("%c %d",ch,num);   
    return 0; 
}

// int main( )
// {
//     int num; 
//     char ch; 
    
    
//     printf("Enter the number"); 
//     scanf("%d",&num); 

//     printf("Enter the character ::"); 
//     scanf("%*c%c",&ch); 

//     printf("%c %d",ch,num); 

//     return 0; 
// }

// int main( )
// {
//     int num; 
//     char ch; 
    
//     printf("Enter the character ::"); 
//     scanf("%*c%c",&ch); 

//     printf("Enter the number"); 
//     scanf("%d",&num); 

//     printf("%c %d",ch,num); 

//     return 0; 
// }

// int main( )
// {
//     char ch; 
//     printf("Enter the character ::");
//     scanf("%*c%c",&ch); 

//     printf("%c",ch);  
//     return 0; 
// }