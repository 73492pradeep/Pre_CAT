#include<stdio.h> 

int main( )
{
   //sizeof() is an operator 
   //sizeof() is evaluated at compile time 

   int num; 
   char ch; 
   double d1; 
   short int s1; 
//    printf("%d ",sizeof(1+2));//int => 4 bytes 
//    printf("%d ",sizeof(num+ch));//int => 4 bytes 
//    printf("%d ",sizeof(10.33 + 'A'));//8 bytes 
//    printf("%d ",sizeof(10.33f + 'A'));//4 bytes 
   
//printf("%d ",sizeof(s1 + ch));// int => 4 bytes 
    
    //int x = 2; 
    //printf("%d \n",sizeof( x + 1) ); // 4 
    //printf("x = %d ",x ) ; //2

   
    
   return 0; 
}