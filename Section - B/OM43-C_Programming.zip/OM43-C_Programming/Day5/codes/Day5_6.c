#include<stdio.h> 

int main( )
{
    int a; 
    float b; 
    a = 23 / 5;// int / int => int    
    //LHS => int 
    //RHS => int  
    // 4.6 => 4
    //printf("%d",a); 

    b = 23 / 5; // int / int => int 
                //  23 / 5 => 4.6 => 4 ( RHS )
    //LHS => b => float 
    //float <= int 
    //4.00  <=  4     
    //printf("%.2f",b); 
    
    b = 23.0f / 5; // float / int => float 
    //RHS => float => 4.6
    //LHS => float 
    // b <=4.6 // b is float 
    printf("%.2f",b); 
    return 0; 
}

/*
if 2 operands are of diff type than smaller 
type is promoted to larger type for calculation 
    double 
    float 
    int 
    char 

    int + int => int 
    int + double => double 
    double + float => double 
    char * int => int 
    short / int => int 
    int / float => float 

   char and short are promoted to "int" for 
   arithmatic calculation 

    char + char => int 
    short + short => int 
    char + short => int 

    typecasting 
    (float)23 => 23 is a int but consider it 
    as a float for this calculation   
*/






/*
    char ch = 500; // 127 to -128 
    
            127 to -128 
            char => 1 byte => 8 bits
            2 to the power 8 => 256 

            1. 500 - 256 => 244  
            2. 244 - 256 => -12 ( yes it is in range ) 

    
            printf("%d",ch); // -12 

    char ch = 900; // 127 to -128

       127 to -128 
       char => 1 byte => 8 bits
       2 to the power 8 => 256 

       900 - 256 => 644 ( no)
       644 - 256 => 388 ( no )
       388 - 256 => 132 ( no )
       132 - 256 => -124 ( Yes )     
*/