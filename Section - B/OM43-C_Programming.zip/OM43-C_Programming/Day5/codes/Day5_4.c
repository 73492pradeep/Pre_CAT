#include<stdio.h> 

int main( )
{
    int num = 2; 
    /*
            2 * 1 = 2 
            2 * 2 = 4 
            2 * 3 = 6 
            2 * 4 = 8 
            2 * 5 = 10  

    */
    // printf( "%d *  %d = %d\n",num,1,num*1); 
    // //       2  *  1  = 2 
    // printf( "%d *  %d = %d\n",num,2,num*2);
    // printf( "%d *  %d = %d\n",num,3,num*3);
    // printf( "%d *  %d = %d\n",num,4,num*4);
    // printf( "%d *  %d = %d\n",num,5,num*5); 

    /*
            2 
            4 
            6 
            8 
            10 
    */
    printf("%d\n",num * 1);
    printf("%d\n",num * 2);
    printf("%d\n",num * 3);
    printf("%d\n",num * 4); 
    return 0; 
}