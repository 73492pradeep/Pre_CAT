#include<stdio.h> 

int main( )
{
    //alias => nickname 
    //datatype => nickname 
    int a;
    //typedef datatype nickname

    typedef int INTEGER;

    int b; 
    INTEGER c;

    size_t d;   

    enum color 
    {
        RED,BLUE,GREEN 
    }; 
    enum color    c1; 
    //datatype  variable
    typedef enum color e_c;   
    e_c c2,c3,c4;  

    return 0; 
}
