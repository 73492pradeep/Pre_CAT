#include<stdio.h> 
int main()
{
    enum operations
    {
        ADD = 1, SUBTRACT, MULTIPLY, DIVIDE
    };
    int num1, num2, result, op,ans;
    enum operations choice;
    do
    { 
        printf("1. Addition \n");
        printf("2. Subtraction \n");
        printf("3. Multiplication \n");
        printf("4. Division \n");

        printf("Enter the num1 and num2"); 
        scanf("%d%d",&num1,&num2); 

        printf("\n Enter the choice");
        scanf("%d", &choice);

        switch (choice) //1 
        {
        case ADD:
            ans = num1 + num2;
            break;

        case SUBTRACT:
            ans = num1 - num2;
            break;

        case MULTIPLY:
            ans = num1 * num2;
            break;

        case DIVIDE:
            ans = num1 / num2;
            break;
        }
        printf("ans = %d", ans);
        printf("\n 1 to continue and 0 to exit");
        scanf("%d",&choice); 
    }while(choice!=0);  
    return 0;
}
