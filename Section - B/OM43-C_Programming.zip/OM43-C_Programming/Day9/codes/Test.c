// #include<stdio.h>
// int main( void )
// {
// char i = 48;
// switch (i)
// {
// case '2': printf("SunBeam Karad");break; //case 50: 
// case '1': printf("SunBeam Market Yard");break;//case 49: 
// default : printf("SunBeam IT Park Hinjewadi");
// }
// return 0;
// }
// #include<stdio.h>
// int main( void )
// {
// int i=5;
// if (!printf("0"))//if(1)=>if(!T)=>if(F)
// i = 3;
// else
// i = 5;
// printf("%d", i);// 05 
// return 0;
// }
// #include<stdio.h>
// int main( void )
// {
// char check = 'a';//97 
// again:
// if(check)//97 => if(97)=>if(T)
// {
// switch (check)//97 
// {
// case ('a'=='b' || 1 ) : printf("PG-DAC "); break; //case 1: 
// case 0 && 'b'=='a' : printf("PG-DMC "); break;//case 0: 
// default : printf("PG-DITISS"); break; 
// }
// }
// else
// goto again;
// return 0;
// }

// #include<stdio.h>
// int main( void )
// {
// int x=101,y=202;
// if(!(!x)&& x)//if( !101=>!T=>F=>!F=>T )
// // if(T && T )=>if(T)
// printf("inside if x=%d\n",x);
// else if(!(!x)&& x)
// printf("inside 1st netsed if x=%d\n",x);
// else if(!(!x)&& x)
// printf("inside 2ed netsed if x=%d\n",x);
// else
// printf("inside else y=%d\n",y);
// return 0;
// }

#include <stdio.h>
int main( void )
{
int value;
value=0;
do
{
++value;// 1 
printf("\n %d",value);//1,1,1,1 ( infinite ) 
value--;//1=> 0 
}while(value>=0);//while(0>=0)=>while(1)=>while(T)
return 0;
}