#include<stdio.h> 

int main( )
{
    enum //annonymous enum 
    {
        RED,BLUE,GREEN
    }c1,c2,c3;  
    return 0; 
}

// int main( )
// {
//     int num = 10; 
//     //enum => code readable 
//     enum color //create the datatype 
//     {
//          RED,BLUE,GREEN
//         //RED=1,BLUE,GREEN
//         //RED=1,BLUE=2,GREEN=3
//         //RED=-1,BLUE,GREEN=3        
//         //RED=0,BLUE,GREEN=3
//         //RED=1.5,BLUE,GREEN=3 // NOT OK 
//         //RED='A',BLUE,GREEN=3
//         //RED=1,BLUE=1,GREEN=3 // OK
//         //RED,BLUE,GREEN,RED  
//         //RED,BLUE,GREEN,RED
//         //RED,BLUE,GREEN,red
//         //RED=num,BLUE,GREEN //there is variable(num)=not allowed
//     }; 

//     //datatype variable-name 
//     // int          x; 

//     enum color c1,c2,c3; 
//     printf("%d",sizeof(c1)); //4 byte 
//     return 0; 
// }
// int main( )
// {
//     //enum 
//     //enum => user - defined datatype   
//     //int,float,char,double 
//     //int => int x; 

//     //enum => code readable 
//     enum color //create the datatype 
//     {
//         RED,BLUE,GREEN 
//     }; 

//     //datatype variable-name 
//     // int          x; 

//     enum color c1,c2,c3; 
//     c1 => variable  
//     c1 = RED; 
//     //printf("%d ",c1); // 0 
//     c2 = BLUE; 
//     //printf("%d ",c2); // 1
//     printf("%d ",GREEN); // 2  
//     c1++; // c1=> 1 
//     //printf("%d ",c1); // 1  
//     //RED++; //not allowed -Lvalue error
//     return 0; 
// }