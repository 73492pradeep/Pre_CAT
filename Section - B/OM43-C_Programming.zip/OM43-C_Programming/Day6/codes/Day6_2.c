#include<stdio.h> 

int main( )
{
    int a = 1; 
    int b = 2; 
    int c = 3;   

    //a+=b+=c+=1; 
    /*
         c = c + 1 => 3 + 1 => 4     
         b = b + c => 2 + 4 => 6 
         a = a + b => 1 + 6 => 7    
    */ 

    a = b = c = -1; 
    printf("%d %d %d",a,b,c); 
    return 0; 
}

// int main( )
// {
//     //short hand assignment => assignment 
//     int num1 = 4;
    
//     //num1+=1; //num1 = num1 + 1;   
//     //num1+=2; //num1 = num1 + 2; 
//     //num1+=3; //num1 = num1 + 3; 
//     //num1-=4; // num1 = num1 - 4;   
//     //num1%=2; // num1 = num1 % 2;    
//     //num1/=2; // num1 = num1 / 2; 
//     printf("%d",num1);  


//     return 0; 
// }
/*
        num1+=1; 
        num1 = num1 + 1;  

    num1 = +1 //unary 
    num1 = -1;

    num1+=1; //shorthand assignment  
    num1-=1; //shorthand assignment   
*/




// int main( )
// {
//     //assignment opr 
//     // ( = )
//     int num1; 
//     //num1 = 2; // assignment  
//     //3 = 2;// NO   
//     //num1 = 2 + 3; //OK 
//     //5 = 2 + 3;// NOT OK  
//     //printf("num = %d",num1); // 2 
    
//     // int a = 3; 
//     // int b = 4; 
//     // printf("%d ",a); // 3 
//     // printf("%d ",a=b);// a is updated to 4  
//     // printf("%d ",a);// 4  
    
    
//     int a = 1;
//     //a+1; 
//     a = a + 1; 
//     printf("%d",a);//2  
    
//     return 0; 
// }