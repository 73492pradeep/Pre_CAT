#include<stdio.h> 

int main( )
{
    //logical opr ( T(1) or F(0))
    // && => logical AND 
    // || => logical OR 
    // ! => logical NOT 

 //Any non-zero value including (-ve ) is considered as true    
 //1,2,3,44,111,2222 , -1, -2 => True 
 //     0 => False    

  // ! => logical NOT => True => !True => False 

    //printf("%d",!100);// 0 
    // 100 => True => !100 => !T => F

    //printf("%d",!-100);// 0
    // T => !T => F 
    //printf("%d",!0);//F => !F=>T => 1  


    //printf("%d ",!!20); //1 
    //!!20 => !20 => !T => F ==> !F => T 
    
    int a; 
    a = !2; 
    // !2 => !T => F => 0 
    printf("%d",a);  
    return 0; 
}

/*
        2!=3 ( relational opr ) 

        int a;
        a = !2 ( logical NOT )  


*/