#include<stdio.h> 

int main( )
{
    //relational operator 
    // > , < , >= , <= , == , !=
    // True or False => 1 or 0 
    // True => 1 
    // False => 0

    printf("%d ", 11 > 2);//T => 1
    printf("%d ", 11 < 2);//F => 0
    printf("%d ", 11 != 2);//T => 1
    // != => not equal to       
    printf("%d ", 11 == 2);//F => 0
    // == => comparison 
    printf("%d ", 11 >= 2);//T => 1
    printf("%d ", 11 <= 2);//F => 0
    return 0; 
}


/*
        == ( relational ) 
        =  (assignment )

*/