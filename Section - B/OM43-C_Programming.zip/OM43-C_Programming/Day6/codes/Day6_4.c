#include<stdio.h> 

int main()
{
    //increment / decrement ( ++ , -- )
    /*
            increment => ++ 
            (increments value by 1 )
            decrement => -- 
            (decrements value by 1 )
    */
   // int ans; 
   // int num = 2; 
   // ans = num; 
   // printf("ans = %d num= %d",ans,num); // 2 2  

//    int ans; 
//    int num = 2; 
//    ans = ++num;
//    /*
//         ++ is written before the operand 
//         pre-increment operator  
//    */ 
//    printf("ans = %d num= %d",ans,num); // 3 3  

//    int ans; 
//    int num = 2; 
//    ans = num++;
//    /*
//         ++ is written after the operand 
//         post-increment operator  
//    */ 
//    printf("ans = %d num= %d",ans,num); // 2 3  

//    int ans; 
//    int num = 2; 
//    ans = --num;
//    /*
//         -- is written before the operand 
//         pre-decrement operator  
//    */ 
//    printf("ans = %d num= %d",ans,num); // 1 1  
   int ans; 
   int num = 2; 
   ans = num--;
   /*
        -- is written after the operand 
        post-decrement operator  
   */ 
   printf("ans = %d num= %d",ans,num); // 2 1  
    
    
    return 0; 
}
/*
        a = 1; 
        a++ or ++a => a = a + 1  

        2++; // 2 = 2 + 1 => Lvalue error 

        a=2; 
        ++a++; // lvalue error   

    c = a++ + a++ + ++a; // Compiler dependent 
    printf("%d %d %d",a,a++,++a); // Compiler dep    

*/