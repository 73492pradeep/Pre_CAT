#include<stdio.h> 

int main( )
{
    int a = 1; 
    int ans; 
    //ans = ++a,++a,++a; 
    //printf("ans = %d a = %d",ans,a); 
    //                        2  4    
    ans = a++,++a,a++; 
    printf("ans = %d a = %d",ans,a); 
    //                        1  4 
    
    int num = 1; 
    num+1; // NO updation 
    num = num + 1; // Yes update 
    num+=1; // Yes update 
    num++; // Yes update 
    // num = num + 1;  
    
    return 0; 
}