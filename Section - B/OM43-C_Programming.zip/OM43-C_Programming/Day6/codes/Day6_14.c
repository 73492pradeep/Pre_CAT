#include<stdio.h> 

int main( )
{
    //int a; 
    //a = printf("Hello world"); 
    //a = printf("Hello"); 
    //a = printf("H e l l o"); 
    //a = printf("Hello world\n"); 
    //a = printf("Hello world"); 
    //printf("\n %d",a); 
    
    //int ans = 10; 
    //int a; 
    //a = printf("ans = %d",ans); 
    //          ans = 10
    //printf("\n %d",a); // 8    
    
    
    int a = 10; 
    int ans; 

    ans = printf(" %10d ",a) + ++a; 
    //              12       +  11 
    //                      1 0
    //    - - - - - - - - - - - -  
    printf("\n %d",ans); // 23 
    return 0; 
}

//int a = printf("Hello"),12;  
//int a = 12,printf("Hello");  
//     a = 12      