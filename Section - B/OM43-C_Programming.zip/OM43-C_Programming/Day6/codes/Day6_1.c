#include<stdio.h> 

int main( )
{
    //Arithmatic opr 
    //+,-,/,% 
    int num1,num2,res; 
    printf("Enter the 2 numbers"); 
    scanf("%d%d",&num1,&num2); 
    res = num1 + num2; 
    printf("res = %d",res); 
    return 0; 
}
