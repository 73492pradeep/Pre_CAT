#include<stdio.h> 
int main(   )
{
    printf("Program execution started ...\n"); 
    printf("Execute ..\n");
    printf("Execute ..\n");
    printf("Execute ..\n");
    int num; 
    //num = 4 / 0; //( run time error )
    printf("num = %d",num); 
    printf("Program end  ..\n"); 
    return 0;
}
//1.Compilation => yes 
//2.Execution => main() 

// OS => main( )