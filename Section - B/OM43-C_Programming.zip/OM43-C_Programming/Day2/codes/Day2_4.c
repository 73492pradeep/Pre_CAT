#include<stdio.h> 

int main( )
{
    /*
        1.Compile time error 
   Error report problems that make it impossible 
   to compile your program 
         
        printf("Hello world") => Compile time error 
        Program will not execute because of error 
        a.exe file will be not be created  

        2.Logical Error ( bug )
            a.Compilation => yes 
            b.Execution => yes 
            c.successfull execution => yes  
            Incorrect o/p( wrong o/p )  

        3.Runtime Error ( program fail) 
        (wrong input )
        a. Compilation => yes 
        b. Execution => Yes 
        c.successfull execution => No   


    */
   /*
            warning 
            1.Compilation => Yes 
            2.Execution => Yes 
     warning report unusual condition in code 
     that may indicate the problem         
     Compilation can proceed 

   */
    return 0; 
}


 