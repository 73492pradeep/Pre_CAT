#include<stdio.h> //header file 


/*
    Author : Ketan Kore 
    Date : 6-3-2023 
    Time : 4.15 PM 
    Description : Printing Hello world 

*/

int main( void )
{
    printf("Hello world"); 
    return 0; 
}

//gcc Day2_1.c

//a.exe 

//Compilation and execution of C program 

