#include<stdio.h> 

void  main( )
{
      printf("hello world"); 
      return 0;    
}

//non-standard 
//void => nothing 
/*void main()
{
    //function not returning anything
}
*/

/*int main( )
{
    printf("Hello world"); 
}*/