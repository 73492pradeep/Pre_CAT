/*
       This is a multiline/block comment 
       Comments are ignored by compiler 
       They are used for sake of documentation 
       or explaination about the program  

*/ 

//This is single line comment 

#include<stdio.h> // this is a header file inclusion 
//stdio.h header file contain standard function declaration 
//we will learn function in detail in function topic  

//main( ) is entry point function in C
//main( ) is a user defined function
//program must have main( ) function at least 
// int => integer   
//void => nothing => main is not accepting any i/p 
int main(   )
{
     
    //printf( ) is used to print some data/string on console 
    //"Sunbeam" , "Hello" , "A" , "AB" => string 
    // 'A' , 'b' , 'C' => character 
    //\n => escape sequence 
    printf("Hello\nworld\n"); 
    return 0; 
//return 0 indicates successfull execution of the program     
// any non zero value indicate program failure 
}


/*
    int main( )
    {
        printf("Hello world"); 
    }


*/
