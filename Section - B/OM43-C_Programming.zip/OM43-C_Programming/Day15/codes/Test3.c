#include<stdio.h> 

void fun( int *p )
{
       ++*p; 
       
}

int main( )
{
    int a = 10; 
    fun( &a );
    printf("\n a = %d",a); // 11   
    return 0; 
}
// void fun( int *p )
// {
//        *p++; 
       
// }

// int main( )
// {
//     int a = 10; 
//     fun( &a );
//     printf("\n a = %d",a);  
//     return 0; 
// }