#include<stdio.h> 
int main()
{
    //string literal 
    char str4[5] = "Tech";
    //Tech is a string constant 
    //short hand decln => 'T 'e' 'c' 'h' 


    char str[] = "Ketan"; 
    /*
            str is a string constant 
             K    e    t    a    n   \0  
            [0]  [1]  [2]  [3]  [4]  [5]
    */

    char str6[4] = "pune"; // it is just a char array 

    

    

    int i; 
    // for( i = 0 ; i < 4 ; i++)
    //       putchar(str6[i]); 



    return 0;
}
/*
    char str[50] = "Pune"
    char str4[4] = {'A','B','C','\0'}; 
    char str[4] = {'A','B'}; // partial init 
    char str[4] = {'A','B','C','D'}; // char array 

*/