#include<stdio.h> 
int main()
{
    char str[] = "Sunbeam infotech";

    //print the string 

    //printf("%s",str); 
    
    // int i; 
    // for( i =0 ; str[i]!='\0';i++)
    //         putchar(str[i]); 

    puts(str); 
    
    return 0;
}
