#include<stdio.h> 
#include<string.h> 
char* mystrcpy(char *dest, const char *src);

int main( )
{
    int res; 
    char src[50] = "Hello"; 
    char dest[50]; 
    //strcpy(dest,src); 
    mystrcpy(dest,src); 
    puts(dest);   
    return 0; 
}
// src => H e l l o \0 
// dest=> H e l l o \0 
                      
char* mystrcpy(char *dest, const char *src)
{
        int i = 0; 
        while(src[i]!='\0')
        {
                dest[i] = src[i];
                i++;  
        }
        dest[i] = '\0';
        return dest;  
}

//geeksforgeeks.com 