#include<stdio.h> 

int main( )
{
    //strcmp(); 
    // char str1[20] = "Sunbeam";
    // char str2[20] = "Sunbeam";
    // if(str1 == str2) // comparing the address 
    //     printf("Same"); 
    // else 
    //     printf("not same"); 

    // char *str1 = "Info"; // pointer to string 
    // char *str2 = "Info";// pointer to string 
    // // memory is allocated from RO data-section 
    // //printf("%u %u",str1,str2);
    // if(str1 == str2)
    //     printf("same"); 
    //  else
    //    printf("not same");    
    
    // char name[10] = "ABC"; 
    // //name[0] = 'K'; // OK 
    // //printf("%s",name); // KBC 

    // char *str1 = "info"; 
    // //printf("%s",str1); 
    // str1[0] = 'K'; // runtime error 
    // // trying to modify the string from RO DATA SECTION 
    // printf("%s",str1);
    
    char str5[20] = "sunbeam"; 

    //printf("%s",str5);  

    printf(str5); //sunbeam
    printf("\n"); 
    printf(str5 + 1 );//unbeam
    printf("\n"); 
    printf(str5 + 2 );//nbeam
    printf("\n"); 
    printf(str5 + 3 );//beam



    return 0; 
}
