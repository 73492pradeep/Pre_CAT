#include<stdio.h> 
#include<string.h> 
int mystrlen(const char *s);
int main( )
{
    int res; 
    char name[50] = "Reader"; 
    //printf("%d",strlen(name)); 
    res = mystrlen(name); 
    printf("%d",res); 
    return 0; 
}
// R e a d e r \0 

int mystrlen(const char *s)
{
        int i = 0; 
        while(*(s+i)!='\0')
        {
            i++; 
        }
        return i; 

}
/*
    *(s+i)=>*(100 + 0) => *(100 + 0  * 1 )=>*(100)
            *(100 + 1) => *(100 + 1  * 1 )=>*(101) 
            *(100 + 2) => *(100 + 2  * 1 )=>*(102) 
*/  