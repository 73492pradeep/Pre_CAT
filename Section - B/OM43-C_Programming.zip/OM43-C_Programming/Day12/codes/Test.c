// #include <stdio.h>
// int no1 = 17, no2 = 71;
// void swapping(void)
// {
// 	int temp = no2;
// 	no2 = no1;
// 	no1 = temp;
// }
// int main(void)
// {
// 	int no1 = 17, no2 = 71;
// 	printf("%d %d ", no1 , no2);//17 71 
// 	swapping();
// 	printf("%d %d\n", no1, no2);//17 71 
// 	return 0;
// }

#include <stdio.h>
int n2 = 11, n1 = 12;

int test(int n1, int n2)
{
	int r1, r2, r3;

	r1 = n1 + n2; r3 = n1 - n2; r2 = n1 * n2;

	return r1, r2, r3;
}

int main(void)
{
	int n1 = 11, n2 = 12;

	printf(" %d ",  test(printf("Sunbeam Pune"), printf("Sunbeam Karad")));

	printf("%d %d\n", n1, n2);

	return 0;
}

