#include<stdio.h> 

int main( )
{
    int num = 10; 
    int *ptr = &num; // referencing opr 
    printf("num = %d\n",num); //10 

    printf("*ptr = %d\n",*ptr);//10 
    /*
            *ptr 
            valueat(ptr)
            valueat(100)
            10 

    */ 
    *ptr = 20; 
    /*
            *ptr 
            valueat(ptr)
            valueat(100) ==> 10 => 20 
    */
    printf("num = %d\n",num); //20 

    printf("*ptr = %d\n",*ptr);//20
    //*ptr => valueat(ptr)=>valueat(100) => 20  

    *ptr = 300; 
    printf("num = %d\n",num); //300 

    printf("*ptr = %d",*ptr);//300
    return 0; 
}
