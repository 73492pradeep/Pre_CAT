#include<stdio.h> 

int main( )
{
    int num = 10; 
    int *ptr = &num; // referencing opr 
    printf("num = %d\n",num); //10 

    printf("*ptr = %d",*ptr);//10 
    /*
            *ptr 
            valueat(ptr)
            valueat(100)
            10 

    */ 
    return 0; 
}
/*
    int *ptr; 
    ptr = &num; 

    int *ptr = &num; 

*/