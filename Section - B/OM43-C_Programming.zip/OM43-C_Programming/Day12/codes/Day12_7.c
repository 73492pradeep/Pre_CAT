#include<stdio.h> 
int main(int argc, char const *argv[])
{
    int num = 10; 
    printf("num = %d\n",num); //10 
    printf("num = %u\n",&num); //10 
    //& => address-of operator 
    //%u => unsigned (address => +ve )
    return 0;
}
