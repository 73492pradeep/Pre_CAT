#include<stdio.h> 
int main()
{
    int num = 10; 
    printf("%d ",num); 
    int *ptr; //declaration of pointer 
 // ptr is a pointer to a integer
 //ptr will be going to store address of int variable     
    
    ptr = &num; //referencing operation 
    
    printf("num = %d\n",num); //10 
    printf("&num = %u\n",&num); //100

    printf("ptr = %u\n",ptr); //100
    printf("&ptr = %u\n",&ptr); //500 
    return 0;
}
/*
    pointer 

    internally it is unsigned int 
    pointer is a special datatype 
    it is not compatible with unsigned int 
    int *ptr = 1000; // NOT OK 

*/