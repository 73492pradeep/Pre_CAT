#include<stdio.h> 

int main( )
{
    int num = 10; 
    int *ptr = &num; // referencing 
    printf("num = %d\n",num); //10
    printf("*ptr = %d\n",*ptr); //10 
    
    *ptr = *ptr + 10; 
    /*
            *ptr
            valueat(ptr)
            valueat(100)
            ==> 10 
            10 + 10 => *ptr => valueat(100)=> updated to 20 

    */
    
    printf("num = %d\n",num); //20
    printf("*ptr = %d\n",*ptr); //20 
    

    return 0; 
}