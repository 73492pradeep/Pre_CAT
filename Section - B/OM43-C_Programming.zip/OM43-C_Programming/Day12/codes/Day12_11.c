#include<stdio.h> 
int main()
{
    int num = 10; 
    int num2 = 30; 
    int *ptr = &num; 
    printf("num = %d\n",num); //10 
    printf("*ptr = %d\n",*ptr); //10
    printf("ptr = %u\n",ptr); //100 
    printf("&num = %d\n",&num); //100  

    ptr = &num2; 
    printf("After update\n"); 
    printf("ptr = %u\n",ptr); //200 
    printf("&num2 = %u\n",&num2); //200

    printf("*ptr = %d\n",*ptr); //30 
    /*
            *ptr 
            valueat(ptr)
            valueat(200)
            30 

    */
    *ptr = 120; 
    printf("num2 = %d\n",num2); //120

    printf("*ptr = %d\n",*ptr); //120 
    return 0;
}
