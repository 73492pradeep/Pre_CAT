#include<stdio.h> 

int main( )
{
    int a = 10; 
    int *p = &a; 
    int *q; 
    q = p; 
    printf("%d ",*p);
    //valueat(p)=>valueat(100) => 10  
    printf("%d ",*q);
    //valueat(q)=>valueat(100) => 10 

    return 0; 
}