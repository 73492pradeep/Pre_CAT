#include<stdio.h>
//self referential structure
struct node 
{
    int data; 
    struct node *next; //self ref pointer 
};  
int main()
{
   
    return 0;
}
