#include<stdio.h> 
struct student {
 char name[20];//20 bytes 
 unsigned int age: 7; // 7 
 unsigned int roll: 6;// 6 
 unsigned int c: 21;// 21
};
//20 + 4  + 4 => 28  

int main( )
{
    printf("%d",sizeof(struct student)); 
    return 0; 
}