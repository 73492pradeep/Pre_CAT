#include<stdio.h> 
//register int z = 500; // NOT OK 
int main( )
{
    //storage => cpu register ( fast accessible)
    register int i;
    printf("%d ",i); // Garbage  
    {
        register int i = 100; 
        printf("%d",i); //100 
    }
    int x; //local var => stack => process => RAM 
    //printf("%u ",&x); // OK 
    //printf("%u ",&i); // NOT OK  

    //int a = 10; // local var 
    //register int *ptr = &a; 
    
    //register int y = 10; 
    //int *ptr = &y; // NOT OK 
    
    //register static int y; // NOT OK 
 
    return 0; 
}

/*
    int num; 
    typedef int INTEGER; 

    INTEGER a; 
    int x; 

    typedef char CHARACTER; 
    CHARACTER ch; 
*/