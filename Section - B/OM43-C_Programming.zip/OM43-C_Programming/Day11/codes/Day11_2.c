#include<stdio.h> 
int sqr(int num); 
int main()
{
    printf("%d",sqr(2)); 
    return 0;
}
int sqr(int num)
{
    return num * num; 
}




// #include<stdio.h> 
// //int sqr(int ); //global declaration  
// int main()
// {
//     //int sqr(int ); //local declaration 
//     int res = sqr( 2 ); 
//     printf("%d",res); 
//     return 0;
// }
// int sqr(int num)
// {
//     return num * num; 
// }

// #include<stdio.h> 
// int sqr(int ); 
// int main()
// {
//     int res = sqr( 2 ); 
//     printf("%d",res); 
//     return 0;
// }
// int sqr(int num)
// {
//     return num * num; 
// }

// int sqr(int num)
// {
//     return num * num; 
// }
// int main()
// {
//     int res = sqr( 2 );
  
//     printf("%d",res); 
//     return 0;
// }

// int sqr(int num); 
// int main()
// {
//     int res = sqr( 2 ); 
//     printf("%d",res); 
//     return 0;
// }
// int sqr(int num)
// {
//     return num * num; 
// }
