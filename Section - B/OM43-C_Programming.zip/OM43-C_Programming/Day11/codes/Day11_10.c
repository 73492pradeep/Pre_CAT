#include<stdio.h> 
void sumpro(int a,int b); 
int ps,pp; // Global variable 
/*
      var declared inside function => local var
      var declared outside  function => Global var  
*/
int main()
{
     int a = 10 , b = 4;  
     sumpro(a,b); //call 
     printf("\n sum = %d prod = %d",ps,pp); 
    return 0;
}
/*
        Global var => can be accessed throughout the porgram 
        stored inside data section 
            //created when program is started 
            //even before main( ) is called 
        //created in datasection  

      //destroyed when program is terminated 
            //after completion of main()      


*/
//             10     4 
void sumpro(int a,int b)
{
    
    
   ps = a + b; // 10 + 4 => 14 
   pp = a * b; // 10 * 4 => 40 
  
  
}

/*
     project --> main.c f1.c f2.c 
                 num1=>global     
                 num2=>static    

*/