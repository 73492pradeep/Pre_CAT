#include <stdio.h>
int fun(void);
int main()
{
    int ans;
    ans = fun();
    printf("%d", ans);
    return 0;
}
int fun(void)
{
    // int r;
    // return r = 1, 2, 3, 4;
    //int r;
    //r = -11,10,1,2,3;
    //return r;
    return (10,20,30,1); //1
    //return 10,20,30,1; //1
    //return 10;
    //return 20;
}
