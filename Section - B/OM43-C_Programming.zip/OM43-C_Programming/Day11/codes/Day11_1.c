#include<stdio.h> 
void display( int result ); 
int addition( int num1 , int num2);
int accept_num( void  );  
int main( )
{
    int num1,num2,res;
    
    num1 = accept_num( ); //10 
    num2 = accept_num( ); //20  
    
    addition(num1 , num2);//30  
    
    return 0; 
}
void display( int result )
{
    printf("res = %d",result); 
}
int addition( int num1 , int num2)
{
    int res; 
    res = num1 + num2; 
    display(res); //function call 
}
int accept_num( void  )
{
    int num1; 
    printf("Enter the num1"); 
    scanf("%d",&num1); 
    return num1; 
}
//main => accept_num(); 

//main => addition( ) => display( ) 