#include<stdio.h> 

int main( )
{
    int c = 10; 
    {
        {
             
            printf("%d ",c); //10 
            c = 100; //assignment 
        }
    }
    printf("\n %d ",c); //100   
    return 0; 
}

// int main()
// {
//    // int c = 10; 
//     {

//         {
//             {
//                 {
//                     {
//                         int c = 100;  
//                         //printf("c = %d",c);     
//                     }
//                 }
//             }
//         }
//     }
//     printf("c = %d",c);     
//     return 0;
// }
