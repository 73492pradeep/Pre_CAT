#include<stdio.h> 
void sumpro(int a,int b); 
extern int ps,pp; //declaration 
int main()
{
     int a = 10 , b = 4;  
     sumpro(a,b); //call 
     printf("\n sum = %d prod = %d",ps,pp); 
    return 0;
}
void sumpro(int a,int b)
{
    
    
   ps = a + b; // 10 + 4 => 14 
   pp = a * b; // 10 * 4 => 40 
}
int ps,pp; // defination Global variable 

