#include<stdio.h> 
void fun( int num ); 
int main( )
{
    int num = 10; 
    //fun( ++num ); 
    fun( num++ ); 
    printf("\n Inside main fun() %d",num);//11  
    return 0; 
}
void fun( int num )
{
    printf("Inside void fun() %d",num); //10 
}