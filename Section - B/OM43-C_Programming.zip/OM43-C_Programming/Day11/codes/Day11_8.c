#include<stdio.h> 
void sumpro(int a,int b); 
int main()
{
     int a = 10 , b = 4;  
     sumpro(a,b); //call 
     //printf("\n sum = %d prod = %d",ps,pp); //NOT OK 
     // ps and pp belong to sumpro function 
     // visible inside only sumpro scope 
    return 0;
}
//             10     4 
void sumpro(int a,int b)
{
    int ps,pp; 
    
   ps = a + b; // 10 + 4 => 14 
   pp = a * b; // 10 * 4 => 40 
  
  
}
