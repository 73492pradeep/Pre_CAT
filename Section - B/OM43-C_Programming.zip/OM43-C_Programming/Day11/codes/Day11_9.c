#include<stdio.h> 
void sumpro(int a,int b); 
int ps,pp; // Global variable 
/*
        ps and pp will be allocated in datasection 
        scope => program 
        life => program 
        by default => 0 
*/
int main()
{
     int a = 10 , b = 4;  
     sumpro(a,b); //call 
     printf("\n sum = %d prod = %d",ps,pp); 
    return 0;
}
//             10     4 
void sumpro(int a,int b)
{
    
    
   ps = a + b; // 10 + 4 => 14 
   pp = a * b; // 10 * 4 => 40 
  
  
}
