#include<stdio.h> 

int num1 = 10; 
int main( )
{
    //int num1 = 100; 
    {
        //int num1 = 1000;
        printf("%d",num1); //10 
    }
    return 0; 
}



#include<stdio.h> 
void fun1( void); 
void fun2( void ); 
extern int num; 
int main()
{
    //extern int num; 
    printf("\nnum = %d",num); 
    fun1( ); 
    fun2( ); 
    return 0;
}
void fun1( void)
{
    //extern int num; 
    printf("\nnum = %d",num); 
}
void fun2( void )
{
    //extern int num; 
    printf("\nnum = %d",num);
}
int num = 100;//defination  
