#include<stdio.h> 
int num4 = 100; // Program scope 
static int num3 = 50;// File scope  
void fun( void ); 
int main()
{
    int x; // local var => main's FAR 
    static int num = 10; //Block scope => data-section 
    printf("num = %d",num); 
    fun( ); 
    return 0;
}
void fun( void )
{
    //printf("num = %d",num); // NOT OK 
    printf("num = %d",num3); //  OK 
}
