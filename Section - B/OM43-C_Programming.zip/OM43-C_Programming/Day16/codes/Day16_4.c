#include<stdio.h> 
/*
        1 => one 
        0 => zero 
        2 => Two 
*/

int main( )
{
    int num; 
    char *numbers[] = {"zero","one","two","three","four"}; 
    //printf("%d ",sizeof(numbers)); //5 * 4 => 20  
    
    printf("Enter the number"); 
    scanf("%d",&num); // 1 
    printf("%s",numbers[num]);//numbers[1] 
    
    return 0; 
}
