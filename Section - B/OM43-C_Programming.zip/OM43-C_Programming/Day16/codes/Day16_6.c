#include<stdio.h>
//command line argument  
int main(int argc, char *argv[],char *envp[])
{
    int i; 
    for(i = 0 ; i < envp[i]!=NULL ; i++)
            puts(envp[i]); 
    //last entry of envp[] is NULL          
    return 0;
}

