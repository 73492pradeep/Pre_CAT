#include<stdio.h> 
int main()
{
    
    return 0;
}
/*
    char *str1 = "One"; 
    char *str2 = "Two";
    char *str3 = "Three";
    char *str4 = "Three";

    char *str[] = {"One","Two","Three","Four"};    
*/
