#include<stdio.h> 


int  main( void )
{
    //int,char,double => datatypes 
    int num = 12;  
    //int => integer 
    char ch = 'A';
    //char => character 
    double dvar = 12.33;

    // format specifiers 
    // int => %d 
    // char => %c 
    // double => %lf 
    //printf("%d\n",num);
    //printf("%c\n",ch);
    //printf("%lf\n",dvar);        
    
    //printf("%d %c %lf",num,ch,dvar);
    //      12 A  12.33
    
    return 0;  
}

