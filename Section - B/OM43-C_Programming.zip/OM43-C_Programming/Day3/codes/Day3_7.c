#include<stdio.h> 

int main( )
{
    int num = 10; 
    float fvar = 12.33; 
    double d1 = 10.33; 
    char ch = 'A'; 
    // sizeof( ) => sizeof is a operator
    // sizeof( ) => size =>bytes  
    //sizeof( ) => bytes => integer => %d  

    // printf("%d\n",sizeof(num)); //4 bytes     
    // printf("%d\n",sizeof(fvar)); //4 bytes   
    // printf("%d\n",sizeof(d1)); //8 bytes  
    // printf("%d\n",sizeof(ch)); //1 bytes          

    printf("%d\n",sizeof(int)); //4 bytes     
    printf("%d\n",sizeof(float)); //4 bytes   
    printf("%d\n",sizeof(double)); //8 bytes  
    printf("%d\n",sizeof(char)); //1 bytes          

    printf("Code sharing utility");
    
    
    return 0; 
}

//MCQ 
//Assignment 

// POLL => Day5 => 4 PM ( 5 to 10 minutes )

// POLL + MCQ ( discuss )