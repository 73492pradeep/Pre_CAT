#include<stdio.h> 

int main()
{
     int number; // variable declaration 
     int roll = 500; //var declaration + init 
     double basic_salary = 1000.00,total_salary=2000.00;
     char ch = 'A'; //variable declan + init
     printf("variables and datatypes..\n");  
     number = 10; // assignment 
     printf("number = %d\n",number);//10
     //      number = 10  
     number = 20; // assignment => overwrite old value => 20 
     printf("%d\n",roll);//500  
      printf("number = %d\n",number);//20 
      //      number = 20
     printf("%.2lf %.2lf\n",basic_salary,total_salary);  
     printf("%d %d\n %lf %lf\n",roll,number,basic_salary,total_salary); 
     printf("%c",ch); 
     return 0; 
}
