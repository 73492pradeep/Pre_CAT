#include<stdio.h> 


int  main( void )
{
    //int,char,double => datatypes 

    
    
    int num1;//variable declaration         
    //variable use  
    int num = 12;//variable declaration + initialization   
    printf("%d\n",num);
    char ch = 'A';//variable declaration + initialization 
    printf("%c\n",ch);
    double dvar = 12.33;//variable declaration + initialization 
    printf("%lf\n",dvar);

    
    
   
    
    
    return 0;  
}

