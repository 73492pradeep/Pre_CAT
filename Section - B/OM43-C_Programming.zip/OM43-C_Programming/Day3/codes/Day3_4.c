#include<stdio.h> 

int main()
{

    // int num1=1; 
    // int num2=2; 
    // int num3=3; 
    // int num4=4; 
 
    //int num1=1,num2=2,num3=3,num4=4; 
    
    //int num1 = 1,double d1 = 12.33;//NOT OK 
    //int num1 = 1;double d1 = 12.33;//OK   
    
    int a=1,b;
    //a => variable decln + init 
    //b => declaration   
    b=12; // assignment 
    
    return 0;  
}
/*
    int a; 
    printf("%d",a); // Garbage //storage class 
*/