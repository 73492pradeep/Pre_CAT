#include<stdio.h> 

int main( )
{
    int num = 50; 
    int num1 = 10; 
    //printf("         %d",num);     
    //width specifier 
    //printf("%10d",num);// right justified 
    //                 5 0 
    // - - - - - - - - - -  
    //printf("%-10d%d",num,num1);// left justified 
    // 5 0                  1 0 
    // - - - - - - - - - - 

    //printf("%010d",num);// right justified 
    // 0 0 0 0 0 0 0 0 1 0 
    // - - - - - - - - - - 

    // int , char , double , float 

    float fvar = 12.33;  
    // float or double 

    //printf("%f",fvar); 
    //printf("%.2f",fvar); 

    //printf("%12.2f",fvar); //right justified 
    //               1 2 . 3 3 
    // - - - - - - - - - - - - 
    //printf("%-12.2f",fvar); //left  justified 
    // 1 2 . 3 3 
    // - - - - - - - - - - - - 

    //printf("%.f",fvar); //12.33 => 12 

    //printf("%012.2f",fvar); //right justified 
     //0 0 0 0 0 0 0 1 2 . 3 3 
    // - - - - - - - - - - - - 
    
    printf("%*.*f",10,2,fvar);
    //      %10.2f
    
    return 0; 
}

/*
        var; => scan( 10)
        printf("%*.*f",var,var-6,fvar);
        //      %12.6  

*/