#include<stdio.h> 

int main( )
{
    //initialization can be done only once 
    //assignment can be done multiple number of times  

    /*
            //ERROR 
            int num2 = 20; 
            int num2 = 20; 

            int num2 = 20; 
            num2 = 30; // OK 
            num2 = 40; //OK 
    */

    int num = 10; //variable decln + init 
    printf("%d",num); //10   
    num = 20;// assignment  
    printf("%d",num); //20  
    num = 33; //assignment 
    num = 44; //assignment
    num = 104; //assignment
    num = -101;//assignment
    printf("%d",num); //-101    
    return 0; 
}
/*
    int num1 = 10; //variable decln + init 
    int num2; // variable decln 

    int num3 = 20; 
    num3 = 40;//assignment


    int num5; //variable declaration 
    num5 = 100; // OK  => assignment 
    printf("%d",num5); //100 

*/