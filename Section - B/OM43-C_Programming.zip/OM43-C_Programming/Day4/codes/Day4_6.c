#include<stdio.h> 
int main()
{
    //char ch = 127; 
    // by default signed 
    // size => 1 byte 
    /*
            1 byte => 8 bits 
            ( 2 to the power 8 - 1) - 1 
            ( 2 to the power 7) - 1
            128 - 1 
            127 => max range 
            -128 => min range  

            1 byte => 8 bits 
            ( 2 to the power 8 ) - 1 
            256 - 1
            255 => max range 
            0 => min range 

    */
    //printf("%d",ch); 
    
    char ch1 = 129; // not in range ( 127 to -128)
    printf("%d",ch1); // -127  
    
    return 0;
}
// (127 to -128)
// -128 -127 -126 -125 ....0 1 2 3 ..... 127 






