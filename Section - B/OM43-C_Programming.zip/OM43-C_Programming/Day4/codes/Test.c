/*
1.
Which one of the following is not a token?
A. int => keyword 
B. _num => identifier 
C. sizeof => keyword 
D. printf => identifier 
E. None of the above
Answer: E

2.
Which one of the following statements will not modify the state of the 
resource?
 i. int a = 10; // OK 
 ii. int 1_a = 15; // Not OK 
iii. 5 = 20 + 1; // Not OK 
    // 5 is a constant 
    // left side of = there should be a variable 
    // int a = 20 + 1  
iv. char c1 = 'C'; // OK 

*/

// #include<stdio.h>
// int main(void)
// {
// //char c1='z'; // 122 
// //printf("%d ",'0');//48 
// //printf("%d ",'9');//57  
// //printf("%d\t%c\t%o",c1-57,c1-'9',c1-32);
// //                  122-57,122-57,122-32 
// // 122 - 57 => %d => integer 
// // 122 - 57 => 65 => %c => character => 'A' 
// // 122 - 32 => 90 => %o => octal     

// //printf("%o",90);// 90 => 132  

// return 0;
// }

// #include<stdio.h>
// int main(void)
// {

// unsigned char c2= -1; // 0 to 255 => 256  
// printf("%u ",c2); // 256 - 1 => 255  
// return 0;
// }

// #include<stdio.h>
// int main(void)
// {
// signed char c1 = -1;
// unsigned char c2= -1;// 255  
// printf("%d\n",c1+c2 );
// //            -1 + 255 => 254    
// return 0;
// }
    