#include<stdio.h> 

int main( )
{
    // Add 2 integer numbers 
    //variable declaration 
    int a,b,c;

    //1.Input 
    printf("Enter the 2 numbers "); 
    scanf("%d%d",&a,&b);//1 2     

    //2.Processing ( + )
    c = a + b; //= ( assignment opr )
    //  1 + 2   
    
    //3. Output 
    printf("addition = %d ",c); 
    
    return 0; 
}


// int main( )
// {
//     int num1; 
//     float fvar; 
//     double dvar; 
//     printf("Enter num1 fvar and dvar"); 
//     scanf("%d%f%lf",&num1,&fvar,&dvar);

//     printf("%d , %.2f , %.2lf",num1,fvar,dvar);    
//     return 0; 
// }


// int main( )
// {
//     int num1,num2; 
//     printf("Enter the num1 and num2 ::\n"); 
//     scanf("%d%d",&num1,&num2); 
//     printf("num1 = %d num2 = %d",num1,num2);
//     return 0; 
// }

// int main( )
// {
//     //scanf( ) => input 
//     // Input 
//     int num1,num2;
//     printf("Enter the number 1 :: \n"); 
//     scanf("%d",&num1);
    
//     printf("Enter the number 2 :: \n"); 
//     scanf("%d",&num2);   
//     //& => address of operator 

//     printf("num1 = %d num2 = %d",num1,num2); 
//     return 0; 
// }
// int main( )
// {
//     //scanf( ) => input 
//     // Input 
//     int num;
//     printf("Enter the int number \n"); 
//     scanf("%d",&num);  
//     //& => address of operator 

//     printf("number = %d",num); 
//     return 0; 
// }