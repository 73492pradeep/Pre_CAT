#include<stdio.h> 

int main( )
{
    // A - Z => 65 - 90  
    // a - z => 97 - 122  
    //char ch = 'A'; // 65 => 65 ka binary 
    // 65 binary stored in 1 byte => 8 bits
    //char ch = 65;
    //char are internally integral constants   
    //printf("%c ",ch); // 65 => 'A' 
    //printf("%d ",ch); // 65 => 65   
    
    //char ch = 'A'; 
    //printf("%d ",ch); // 'A' => 65 
    //printf("%c ",ch); // 'A' => 65 

    //\n \t \b \r => char
    // \n => ascii => %d
    //printf("%d ",'\n');// \n => ascii => 10
    //printf("%d ",'\t');// \t => ascii => 9 

    //printf("%d ",'\n' - '\t');
    //            10  -  9 => 1   

    printf("%d ",'A' - 'A');
    //            65 - 65 => 0   

    return 0; 
}