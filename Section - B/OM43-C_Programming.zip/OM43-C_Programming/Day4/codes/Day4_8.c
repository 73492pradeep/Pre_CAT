#include<stdio.h> 

int main( )
{
    char ch; 
    // printf("%d ",sizeof(10)); // 4 bytes 
    // // 10 => int => 4 byte  
    // printf("%d ",sizeof('A'));// sizeof(65); 
    // // 'A' => char const => int => 4 byte   
    // printf("%d ",sizeof(ch));
    // // ch => variable => char => 1 byte  

    //printf("%d ",sizeof(11.33)); // double 
    // double => 8 bytes 
    //printf("%d ",sizeof(11.33f));//float 
    //11.33f => float => 4 bytes 
    //printf("%d ",sizeof(11.33F));//float  
    
    // printf("%d ",sizeof(10l));//long => 4 bytes 
    // printf("%d ",sizeof(10L));//long => 4 bytes  
    // printf("%d ",sizeof(10LL));//long long => 8 bytes 
    // printf("%d ",sizeof(10ll));//long long => 8 bytes 
    
    //printf("%d",100); // int
    //printf("%d\n",0100); //65 octal to decimal   
    //printf("%o",0100);// 100  // octal to octal   
     
    //printf("%d\n",0x23);// 35 //hexadecimal to decimal
    //printf("%x\n",0x23);// 23 //hexadecimal to hexadecimal     
    
    
    printf("%d %o %x %c",65,65,65,65); 
    
    
    
    return 0; 
}

/*
    1.Classwork 
    2.Try to solve assignment 
    3.MCQ ( solve )

    LAB session 
    1.Assignment doubt 
    2.Technical doubrt ( MCQ + classwork)
    3.Installation 

    use zoom channel 


    10.33 => double 
    10.33f => float 
*/