#include<stdio.h> 
#include<limits.h> 

int main( )
{
    /*
        type modifiers 
        signed 
        unsigned 
        short 
        long 
    */


    int num = 2147483647; 
    // by default it is considered as signed 
    // int datatype => 4 byte => 32 bits 
    //printf("%d",num); 
    printf("%d\n",INT_MAX); 
    printf("%d\n",INT_MIN); 
    /*
            int => 4 bytes 
            32 bits 
            1 bit => sign (MSB)
           (2 to the power 32 - 1 ) - 1  
           (2 to the power 31 ) - 1 
           2147483647 => max range  
           -2147483648 => min range 
    */

    return 0; 
}
/*
    signed => + as well - 
    unsigned => only + 

    10 => 1010
    
*/

/*
                32 bits 
    00000000 00000000 00000000 00000001  

    Number system 
    (conversion)
    decimal 
    Binary 
    octal 
    hexadecimal 

    1s Compliment 
    2s Compliment 

*/