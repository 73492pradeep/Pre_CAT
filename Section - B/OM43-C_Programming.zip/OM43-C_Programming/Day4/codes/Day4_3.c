#include<stdio.h> 
#include<limits.h> 

int main( )
{
    unsigned int num = 4294967295;
    //printf("%u",num); 
    //printf("%d",sizeof(num)); // 4 bytes 
    /*
            4 bytes => 32 bits 
            (2 to the power 32 ) -1 
            4294967295  = max range 
            0 => min range 

    */
    printf("%u ",UINT_MAX); //4294967295  
    // %u => unsigned  
    return 0; 
}