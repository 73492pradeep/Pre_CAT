#include<stdio.h> 

int main( )
{
    //escape sequence 
    //\n => newline 
    //printf("Hello\nworld");     
    
    //\" 
    //printf("\"Hello world\""); 
    
    //printf("\'Hello world\'"); 
    
    //\b => backspace 
    
    //printf("Sunbeam info,\b."); 
    //      Sunbeam info.
    
    //printf("Hello wo\brld");
    //      Hello wrld 
    
    // \t => tab => 8 spaces 
    //printf("12345678\n"); 
    //printf("\tSunbeam");

    //\r => carraige return      
    //printf("KM 43batch\rO");
    //        KM 43batch 

    //printf("\\n is used for new line"); 

    printf("Discount is 10%%"); 

    return 0; 
}