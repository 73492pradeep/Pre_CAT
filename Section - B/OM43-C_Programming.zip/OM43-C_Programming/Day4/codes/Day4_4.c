#include<stdio.h> 
#include<limits.h> 

int main()
{
    //short , long
    //short int num = 32767;  
    //signed short int num; 
    //unsigned short int num; 
    //printf("%d",sizeof(num)); // 2 bytes 
    /*
            2 byte
            16 
            ( 2 to the power 16 -1 ) - 1
            ( 2 to the power 15 ) - 1
              32768 - 1 
              32767 => max range 
              -32768 => min range  

    */
    //printf("%hd",num); //%hd => short int 
    //printf("%d\n",SHRT_MAX);
    //printf("%d",SHRT_MIN);
    //printf("%d ",USHRT_MAX); 

    //long 
    //long int num; 
    //signed long int num; 
    //unsigned long int num; 
    //printf("%d",sizeof(num)); // 4 byte 
    
    //long long int num1; 
    //signed long long int num1; 
    //unsigned long long int num1; 
    //printf("%d",sizeof(num1)); // 8 bytes 
    // 8 bytes => 64 
    
    
    return 0; 
}
/*
    50 
    int num; // 4 bytes 
    unsigned int num; // 4 bytes 
    short int num; // 2 bytes 
    unsigned short int num; // 2 bytes 
    long int num; // 4 bytes 
    unsigned long int num; // 4 bytes 
    long long int num; // 8 bytes 
    unsigned long long int num; // 8 bytes 


    11.33 
    float => 4 bytes 
    double => 8 bytes 



*/