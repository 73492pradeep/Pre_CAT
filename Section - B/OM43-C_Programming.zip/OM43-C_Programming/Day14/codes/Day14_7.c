#include<stdio.h> 

void printArray( int *a) ; 
int main( )
{
    int i; 
    int arr[4]= {100,200,300,400}; 
    printArray(arr);
    printf("\nInside the main");  
     for(i = 0 ; i < 4 ; i++)
        printf("\n %d ",arr[i]);     
    return 0; 
}



void printArray( int *a) 
{
     //printf("%d ",*a);
     //a++;  // 500 => 504 
     //printf("%d",*a);
     //printf("%d ",a[-1] );//100 
     /*
            a[-1]
            *(a + -1)
            *(a - 1)
            *(504 - 1 )
            *(504 - 1 * 4)
            *(504 - 4)
            *(500)
            valueat(500)=> 100 
     */

     int i;
     printf("inside the function \n");  
     for(i = 0 ; i < 4 ; i++)
           printf("%d ",a[i]);     

      for(i = 0 ; i < 4 ; i++)
          a[i]++;          

}

/*

    if starts from 1 

     1   2   3   4   5  
    [1] [2] [3] [4] [5]
   100  104 108 112 116 

   arr[1] => 1 

   arr[1]
   *(arr + 1)
   *(100 + 1) 
   *(100 + 1 * 4)
   *(104)
   valueat(104)
   2   

*/