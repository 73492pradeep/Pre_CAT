#include<stdio.h> 

int main( )
{
    int num = 10; 
    const int *ptr = &num; 

    printf("num = %d ",num);//10
    printf("*ptr = %d ",*ptr);//10 

    //*ptr = 20; 
    printf("num = %d ",num);//20
    printf("*ptr = %d ",*ptr);//20 

    num = 50; 
    return 0; 
}
// int main( )
// {
//     const int num = 10; 
//     int *ptr = &num; 

//     printf("num = %d ",num);//10
//     printf("*ptr = %d ",*ptr);//10 

//     *ptr = 20; 
//     printf("num = %d ",num);//20
//     printf("*ptr = %d ",*ptr);//20 

//     return 0; 
// }