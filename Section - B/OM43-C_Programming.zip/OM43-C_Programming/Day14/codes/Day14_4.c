
#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

      int arr[5] = {11,22,33,44,55}; 
    /*
        arr 

           11  22   33   44   55   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

        
    */  
    int *ptr = arr; // pointer to array  

    //printf("%d ",*ptr); // 11   

    printf("%d ",++*ptr);//12
    //printf("%d ",arr[0]); // 12   

    printf("%d ",*++ptr); //22 

    printf("%d ",*ptr++); //22 
    printf("%d ",*ptr);  //33 
    return 0; 
}

//++*ptr++; 
