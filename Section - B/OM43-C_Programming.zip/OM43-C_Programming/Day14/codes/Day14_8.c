#include<stdio.h> 

int main( )
{
    //type qualifier 
    // const , volatile 
    const int num = 10; 
    printf("%d",num); //10 
    //num = 100; // NOT OK 
    return 0; 
}