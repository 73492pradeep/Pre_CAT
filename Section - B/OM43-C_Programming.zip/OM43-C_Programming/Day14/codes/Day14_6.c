#include<stdio.h> 
void readArray( int *ptr); 
void printArray( int arr[]); 
int main( )
{
    int arr[5]; 
    printf("Enter the array elements ::"); 
    readArray( arr );
    printf("Array elements are :: "); 
    printArray(arr);  
    return 0; 
}

void readArray( int *ptr) //pointer notation 
{
    //printf("%d ",sizeof(ptr)); //4 ( pointer size) 
     int i; 
     for(i = 0 ; i < 5 ; i++)
          scanf("%d",&ptr[i]);// 1 2 3 4 5    

}


void printArray( int arr[]) //array notation 
{
    
     int i; 
     for(i = 0 ; i < 5 ; i++)
          printf("%d",arr[i]);   

}

