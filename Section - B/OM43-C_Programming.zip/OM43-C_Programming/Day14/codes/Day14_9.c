#include<stdio.h> 
int main()
{
    int num = 10; 
    int num2 = 50; 
    int *ptr = &num; 

    printf("num = %d\n",num);//10 
    printf("*ptr = %d\n",*ptr);//10  
    
    num = 20; 
    printf("num = %d\n",num);//20 
    printf("*ptr = %d\n",*ptr);//20
    
    *ptr = 100; 
    printf("num = %d\n",num);//100 
    printf("*ptr = %d\n",*ptr);//100
    
    ptr = &num2; 
    printf("*ptr = %d\n",*ptr);//50
    return 0;
}
