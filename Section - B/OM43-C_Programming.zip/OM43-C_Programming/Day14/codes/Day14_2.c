
#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

      int arr[5] = {1,2,3,4,5}; 
    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */  
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",&arr[index]); 
    printf("\n\n "); 
    /*
            &arr + 1 
            100 + 1 
            100 + 1 * 20 
            120 
    */

    //int *ptr = (int*)&arr+1;
     int *ptr = &arr+1;
    //printf("%d ",*ptr); //G
    ptr--;    
    /*
            ptr = ptr - 1 
                = 120 - 1 
                = 120 - 1 * 4 
                = 120 - 4 
                = 116 
    */
   printf("%d ",*ptr);  
    return 0; 
}
