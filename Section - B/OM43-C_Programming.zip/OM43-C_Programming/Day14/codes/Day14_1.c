
#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

      int arr[5] = {1,2,3,4,5}; 
    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */  
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",&arr[index]); 
    printf("\n\n "); 
    
    //arr++; //100 = 100 + 1 => NOT OK 
    int *ptr1 = &arr[4]; //116 
    int *ptr2 = &arr[0]; //100 
    int ans; 
    ans = ptr1 - ptr2;
    /*
            (ptr1 - ptr2) / scale factor of ptr1 
            (116 - 100) / 4 
                16 / 4 
                  4 

    */  
    //printf("ans = %d",ans); //4 
    
    //printf("%u ",arr); // 100 
    //printf("%u ",arr + 1); // 104 

     printf("%u ",&arr); // 100

     printf("\n%u ",&arr + 1 ); 
     /*
            100 + 1 * 20 
            120 
     */ 

    return 0; 
}
/*
    int num1 = 10; // 100
    int num2 = 20; // 104

    int *ptr1 = &num1;//100  
    int *ptr2 = &num2;//104 
    ptr2 - ptr1 =>   

    (ptr2 - ptr1) / scale factor of ptr1 
    (104 - 100) / 4 
    (4) / 4 
     1   

*/


