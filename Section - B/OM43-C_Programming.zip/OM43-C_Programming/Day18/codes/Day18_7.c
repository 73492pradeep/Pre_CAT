#include <stdio.h>

#define DISCLAIMER  printf("This video is property of Sunbeam Infotech.\n"); \
					printf("Copying/Downloading is not expected.\n"); \
					printf("Sharing others is Piracy.\n"); \
					printf("Eligible for Cyber crime case.\n"); \
					printf("Enjoy learning not social work.\n");


void disclaimer() {
	printf("This video is property of Sunbeam Infotech.\n");
	printf("Copying/Downloading is not expected.\n");
	printf("Sharing others is Piracy.\n"); 
	printf("Eligible for Cyber crime case.\n"); 
	printf("Enjoy learning not social work.\n");
}

int main() {
	DISCLAIMER
	DISCLAIMER
	DISCLAIMER
	DISCLAIMER
	DISCLAIMER
	disclaimer();
	disclaimer();
	disclaimer();
	disclaimer();
	disclaimer();
	return 0;
}
// inline function ==> C++ 

// macro ==> command ==> preproc