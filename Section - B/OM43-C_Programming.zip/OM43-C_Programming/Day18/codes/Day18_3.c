#include<stdio.h> 

#define ADD(a,b) (a+b)
#define MULTIPLY(a,b) (a*b)
#define SQR(x) ((x) *(x))



int main( )
{
    printf("add = %d\n",ADD(3,4)); // 7  
   //printf("add = %d\n",(3+4));//7
   printf("Multiply = %d\n",MULTIPLY(3,4));//12 
   //printf("Multiply = %d\n",(3*4));   

   printf("Multiply = %d\n",MULTIPLY(2+1,3+1));//6 
   //printf("Multiply = %d\n",(2+1 * 3+1));
   printf("SQR = %d\n",SQR(2+3)); 
   //printf("SQR = %d\n",((2+3) *(2+3))); 
   
    return 0; 
}