
//macro / symbolic constant 

#define PI 3.1412 

//functions declarations 


//variable declarations 


//struct / union / enum declarations 