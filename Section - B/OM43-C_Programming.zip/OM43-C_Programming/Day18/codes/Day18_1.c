#include<stdio.h> 
#include"Day18_1.h" 

int main()
{
    double rad,area; 

    printf("Enter the radius"); 
    scanf("%lf",&rad); 

    area = PI * rad * rad; 
    printf("area = %.2lf ",area); 
    return 0;
}
// To create .i file 
//gcc Day18_1.c -E -o Day18_1.i