
#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

      int arr[5] = {1,2,3,4,5}; 
    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */  
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",&arr[index]); 
    printf("\n\n "); 
    //array name represents the base address 


    printf("%d ",arr[0]); //1 (Array notation )
    /*
            arr[0]  =>  *(arr + 0 ) 
    */ 
    printf("%d ",*(arr + 0));//pointer notation 
    printf("%d ",arr[1]); //1 (Array notation )
    printf("%d ",*(arr + 1));//pointer notation 
    /*
        array N            pointer notation  
            arr[2]   => *(arr + 2)
            arr[3]   => *(arr + 3)
            arr[4]   => *(arr + 4)


    */
    
    return 0; 
}
