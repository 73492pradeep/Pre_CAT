#include<stdio.h> 

void fun( int **p ); 
int main( )
{
    int n = 10;
    int *ptr = &n; 
    printf("Before call value  %d\n ",n); //10  
    fun( &ptr ); 
    printf("\n inside the main n = %d",n);//20  
    return 0; 
}
void fun( int **p )
{
      printf("%d \n",**p); // 10 
      //**p = 20; 
      **p = **p + 10; 
      printf("%d \n",**p); // 20  
}

// void fun( int *p ); 
// int main( )
// {
//     int n = 10;
//     printf("Before call value  %d\n ",n);  
//     fun( &n ); 
//     printf("\n inside the main n = %d",n);//20  
//     return 0; 
// }
// void fun( int *p )
// {
//     printf("\n Inside the function %d",*p);// 10
//     *p = *p + 10; 
//       // *p => valueat(p) => valueat(100)=> 10  
//       // 10 => 20 
//       printf("\n After update Inside the function %d",*p);// 10
// }

