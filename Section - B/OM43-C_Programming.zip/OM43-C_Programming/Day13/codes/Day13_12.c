#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

    //arrays
    //int arr[5] = {1,2,3,4,5}; //init list
    //int arr[5] = {1}; //partial init 
    //int arr[5];// Garbage  
    //int arr[]; // NOT OK 
    //int arr[] = {1,2,3,4,5}; // OK 
    int arr[5] = {1,2,3,4,5,6,7}; //not OK 
    // bound checking is task of programmer 

    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */  
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",arr[index]); 
    return 0; 
}
/*
    //array behaviour => static 
    int arr[100] = {1}; // 100 * 4 => 400 bytes  

     static => compile time 
     dynamic => runtime  (dynamic mem allocation )  

     
*/