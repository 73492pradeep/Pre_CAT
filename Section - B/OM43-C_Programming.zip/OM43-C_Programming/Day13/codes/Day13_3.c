#include<stdio.h> 

int main( )
{
    int num = 10; 
    int *ptr = &num; //referencing 
    int **pptr = &ptr ;//pointer to pointer  
//pptr is a pointer which will store address of pointer to int     
    printf("num = %d",num); //10
    printf("*ptr = %d",*ptr); //10
    printf("**pptr = %d",**pptr); //10 
    **pptr = 20; 
    printf("after update ...\n"); 
    printf("num = %d",num); //20
    printf("*ptr = %d",*ptr); //20
    printf("**pptr = %d",**pptr); //20 
    return 0; 
}
