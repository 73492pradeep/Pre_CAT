#include<stdio.h> 
int main()
{
    char ch = 'A'; 
    char *cptr = &ch; 
    char **cpptr = &cptr; 

    //printf("%d ",sizeof(ch)); //1 byte 
    //printf("%d ",sizeof(cptr)); //4 byte
    //printf("%d ",sizeof(*cptr)); //scale factor //1 byte   
    
    printf("%d ",sizeof(cpptr));// 4 bytes( pointer size ) 
    printf("%d ",sizeof(*cpptr));// 4 bytes 
    /*
                *cptr 
                valueat(cptr)
                sizeof(valueat(500)) => 4 byte  

    */
    printf("%d ",sizeof(**cpptr));// 1 bytes 
    
    return 0;
}
