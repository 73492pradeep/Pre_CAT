
#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

      int arr[5] = {1,2,3,4,5}; 
    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */  
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",&arr[index]); 
    printf("\n\n "); 
    //array name represents the base address 

    printf("%u ",arr); // 100 

    //printf("%u ",*arr); 
    /*
            *arr 
            valueat(arr)
            valueat(100)
            1 

    */
    //printf("%u ",*(arr + 0) );//1 
    /*
            *(arr + 0)
            valueat( 100 + 0)
            valueat( 100)
            1 

    */ 
     printf("%d ",*(arr + 1) );//2  
     /*
                *(arr + 1 )
                *(100 + 1 )
                *(100 + 1 * 4)
                *(104)
                valueat(104)
                2 
     */   
    
    return 0; 
}
