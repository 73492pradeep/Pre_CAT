
#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

      int arr[5] = {1,2,3,4,5}; 
    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */  
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",&arr[index]); 
    printf("\n\n "); 
    
    int *ptr = arr;   
    //int *ptr = &arr[0];   
    
    //printf("%u %u",ptr,arr); //100 100  
    
    printf("%u ",*(ptr + 1)); //2 => pointer notation 
    printf("%u ",ptr[1]); //2 => array notation 
    /*
            array          pointer notation 
            ptr[1]   ===> *(ptr + 1 )
            
    */
    printf("%u ",1[ptr]); //array notation 
    printf("%u ",ptr[2-1]);// array notation 
    printf("%u ",*(ptr + 2 - 1));// pointer notation 
    printf("%u ",*(1 + ptr )); // pointer notation 

    printf("%d ",ptr[-1]); 
    /*
            ptr[-1]
            *(ptr + -1)
            *(ptr - 1)
            *(100 - 1)
            *(100 - 1 * 4)
            *(96)
            Garbage 

    */ 
    return 0; 
}



