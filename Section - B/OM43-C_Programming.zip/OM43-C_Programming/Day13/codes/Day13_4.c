#include<stdio.h> 

int main()
{
    int num = 10; 
    int *ptr = &num; 

    //*ptr =200; 

    char ch ='A'; 
    char *cptr = &ch; 

    float fvar = 11.3; 
    float *fptr = &fvar; 

    double dvar = 10.3; 
    double *dptr = &dvar; 

    //printf("%d %c %.2f %.2lf",*ptr,*cptr,*fptr,*dptr);     
    printf("%d ",sizeof(*ptr));//4 
    printf("%d ",sizeof(*cptr));//1
    printf("%d ",sizeof(*fptr));//4 
    printf("%d ",sizeof(*dptr));//8 
    return 0;
}
