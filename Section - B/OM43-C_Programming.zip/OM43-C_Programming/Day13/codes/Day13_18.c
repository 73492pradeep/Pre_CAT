
#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

      int arr[5] = {1,2,3,4,5}; 
    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */  
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",&arr[index]); 
    printf("\n\n "); 
    
    int *ptr = arr;   
    //int *ptr = &arr[0];   
    
    //printf("%u %u",ptr,arr); //100 100  
    
    printf("%u ",ptr); //100 

    printf("%u ",ptr+1);//104 
    /*
                ptr + 1 
                ptr + 1 * scale factor of ptr 
                ptr + 1 * 4 
                100 + 4 
                104 

    */
    printf("%u ",ptr+2);//108  
    /*
                ptr + 2 
                ptr + 2 * scale factor of ptr 
                ptr + 2 * 4 
                100 + 8 
                108 

    */
    return 0; 
}
