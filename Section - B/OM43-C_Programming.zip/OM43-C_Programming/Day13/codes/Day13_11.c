#include<stdio.h> 

int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

    //arrays
    int arr[5] = {1,2,3,4,5}; //init list
    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */
     //printf("%d %d %d",arr[0],arr[3],arr[2]); 
     //                  1      4       3  
    
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",arr[index]); 
    return 0; 
}