
#include<stdio.h> 
//int arr[5];// 0 
int main( )
{
    //int n1=1,n2=2,n3=3,n4=4,n5=5; 

      int arr[5] = {1,2,3,4,5}; 
    /*
        arr 

           1    2    3    4    5   
          [0]  [1]  [2]  [3]  [4]  (index)
          100  104  108  112  116  

          arr[0] => 1 
          arr[3] => 4 
          arr[2] => 3 
    */  
    int index;
    for(index = 0 ; index < 5 ; index++)
            printf("%d ",&arr[index]); 
    printf("\n\n "); 
    
    // printf("%d ",arr[1]); //2 (array notation )
    // printf("%d ",1[arr]); //2 (array notation )
    // printf("%d ",*(arr + 1) ); //2 (pointer notation )
    // printf("%d ",*(1 + arr) ); //2 (pointer  notation )
    // printf("%d ",*(arr + 2 - 1 ) ); //2 (array notation )

    //printf("%d ",*arr + 2 ); //3 
    //             1  + 2  
    /*
            *arr 
            valueat(arr)
            valueat(100)
            1 
    */
    //printf("%d ",arr [ arr[0] ] ); 
    //           arr [    1     ]
    //               2     
    
    printf("%d ",arr[-1] );// Garbage 
    /*
             arr[-1]
             *(arr + -1)
             *(arr - 1)
             *(100 - 1 )
             *(100 - 1 * 4)
             *(100 - 4)
             *(96)
             valueat(96)   

    */ 
    
    return 0; 
}
