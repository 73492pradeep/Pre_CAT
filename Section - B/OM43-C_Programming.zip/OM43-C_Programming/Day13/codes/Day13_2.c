#include<stdio.h> 

int main( )
{
    int num = 10; 
    int *ptr = &num; //referencing 
    int **pptr = &ptr ;//pointer to pointer  
//pptr is a pointer which will store address of pointer to int     
    

   //printf("num = %d ",num); 
   //printf("*ptr = %d ",*ptr); //10 
   /*
            *ptr 
            valueat(ptr)
            valueat(100)
            10 
   */
    //printf("**pptr = %d ",**pptr);//10  
    /*
            **pptr 
            valueat(valueat(pptr)); 
            valueat(valueat(500));
            valueat(100)
            10  

    */
    printf("*pptr = %u",*pptr);//100 
    /*
            *pptr 
            valueat(pptr)
            valueat(500)
            100
    */ 
    printf("*num = %u",&num);//100  
    return 0; 
}
