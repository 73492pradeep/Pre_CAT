#include<stdio.h> 
int main()
{
    int num1 = 10;
    int num2 = 20; 

    int *ptr1 = &num1; 
    int *ptr2 = &num2;
    int ans; 

    //ans = ptr1 + ptr2;// NOT OK 
    //ans = ptr1 * ptr2;// NOT OK
    //ans = ptr1 / ptr2;// NOT OK
    //ans = ptr1 % ptr2;// NOT OK   
    //ans = ptr1 - ptr2;//  OK 

    ans = *ptr1 + *ptr2;
    //      10  +  20 
    printf("ans = %d",ans);//30      
    return 0;
}
