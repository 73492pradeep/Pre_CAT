#include<stdio.h> 

int main( )
{
    int n1,n2,n3,n4,n5; 

    //arrays
    int arr[5]; //array declaration (1D array)  
    //int => integer 
    //arr => name of array 
    //[5] => size of array (compulsory ) 
    /*  
            double darr[10];//10 float values 
            float farr[20]; //20 float values 
    */
    return 0; 
}