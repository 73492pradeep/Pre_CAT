#include<stdio.h> 
int main()
{
    //pointer arithmatic 

    int num = 10; 
    int *ptr = &num; 
    printf("&num = %d\n",&num); //100 
    printf("&num = %d\n",ptr); //100 

    //pointer arithmatic

    ptr = ptr + 1; 
    /*
            ptr + n = ptr + n * scale factor of ptr

            ptr + 1 
            ptr + 1 * scale factor of ptr 
            100 + 1 * scale factor of ptr 
            100 + 1 * 4
            100 + 4 
            104 
    */
    printf("\n ptr = %u",ptr); //104 
    ptr--; 
    /*
        ptr = ptr - 1 
            = 104 - 1 
            = 104 - 1 * scale factor of ptr 
            = 104 - 1 * 4 
            = 104 - 4 
            = 100 
    */
    printf("\n ptr = %u",ptr); //100 
    printf("\n *ptr = %d",*ptr); //10  
    
    //ptr = ptr / 1; // NOT OK 
    //ptr = ptr * 1; // NOT OK   
    
    return 0;
}
/*
    ptr = ptr + 50 
          ptr + 50 * 4 => 200 bytes 

    ptr - 20; 
    ptr - 20 * 4 => 80 bytes 

    double *dptr;

    dptr + 30; 
    dptr + 30 * 8 => 240 bytes          

*/