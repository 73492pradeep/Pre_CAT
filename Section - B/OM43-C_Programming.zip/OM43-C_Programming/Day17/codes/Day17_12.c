#include<stdio.h> 
#include<stdlib.h> 

int main()
{
    //dynamic memory allocation (heap)
    // void* malloc (size_t size); 
    float *ptr; // stack  

    ptr = (float*)malloc(sizeof(float)); //Request 
    
    if(ptr == NULL) // check if avail 
    {
        printf("Memory not allocated"); 
        exit(1); 
    }
    *ptr = 12.33; //use 
    printf("%.2f",*ptr); 
    free(ptr);//To avoid memory leakage  
    ptr = NULL; //To avoid dangling pointer 
    return 0;
}
