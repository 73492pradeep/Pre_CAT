#include<stdio.h> 
int main(int argc, char  *argv[])
{
    // printf("%u ",argv[0]); 
    // printf("%u ",argv[1]);
    // printf("%u ",argv[2]);  

    // printf("%c ", *(*(argv + 0) + 0));
    // printf("%c ", *(*(argv + 0) + 1));
    // printf("%c ", *(*(argv + 0) + 2)); 
    // printf("%c ", *(*(argv + 0) + 3));

     printf("%c ", argv[0][0]); // a 
     return 0;
}
